<?php
    $pdf=new PDF_Code39('P','mm',array(210,297));
    $pdf->SetMargins(2,2); 
    $pdf->AddPage();

    foreach ($data->result() as $value) {
        $nama = $value->nama;
        $no_ktna = $value->no_ktna;
        $utusan = $value->wilayah;
        $foto = $value->foto;
        $barcode = $value->barcode;
    }

    if($foto != null){
        $foto = $foto;
        $format = explode(".",$foto);
        $format = $format[1];
    }else{
        $foto = "kosong.png";
        $format = "png";
    }

    $pdf->Ln(6);
    $pdf->setFont('Arial','',10);
    $pdf->setFillColor(255,255,255);
    $pdf->Image(base_url().'assets/dist/img/favicon/logo-tanwir-192x192.png', 15, 8,'22','22','png');

    $pdf->Ln(2);
    $pdf->setFont('Arial','',14);
    $pdf->setFillColor(255,255,255); 
    $pdf->cell(195,6,'Bukti Registrasi',0,1,'C',0); 
    $pdf->cell(195,6,"Tanwir 1 Nasyiatul Aisyiyah",0,1,'C',0); 
    $pdf->cell(195,6,'Banjarmasin, 3-5 November 2017',0,1,'C',0);
    $pdf->Ln(3.5);
    $pdf->setFillColor(0,0,0);
    $pdf->cell(195,0.3,'',1,1,'C',1);


    $pdf->Ln(12);
    $pdf->setFont('Arial','B',10);
    $pdf->setFillColor(75,183,119);
    $pdf->Image(base_url().'assets/dist/img/peserta/'.$foto, 10, 45,'35','40',$format);
    $pdf->cell(50,6,'',0,0,'C',0);
    $pdf->cell(33,6,'Nama',0,0,'L',0);
    $pdf->cell(1,6,':',0,0,'C',0);
    $pdf->cell(119,6,$nama,0,1,'L',0);
    $pdf->Ln(3);
    $pdf->cell(50,6,'',0,0,'C',0);
    $pdf->cell(33,6,'No. KTNA',0,0,'L',0);
    $pdf->cell(1,6,':',0,0,'C',0);
    $pdf->cell(119,6,$no_ktna,0,1,'L',0);
    $pdf->Ln(3);
    $pdf->cell(50,6,'',0,0,'C',0);
    $pdf->cell(33,6,'Utusan',0,0,'L',0);
    $pdf->cell(1,6,':',0,0,'C',0);
    $pdf->cell(119,6,$utusan,0,1,'L',0);
    $pdf->Ln(3);
    $pdf->cell(50,6,'',0,0,'C',0);
    $pdf->cell(33,6,'Acara yang diikuti',0,0,'L',0);
    $pdf->cell(1,6,':',0,0,'C',0);
    $i = 1;
    $tot = 0;
    foreach ($acara->result() as $value) {
        if($i != 1){
        $pdf->cell(84,6,'',0,0,'C',0);
        }
        $pdf->cell(119,6,$i.". ".$value->nama_acara,0,1,'L',0);
        $pdf->Ln(3);
        $i++;
        $tot = $tot + 9;
    }
    $pdf->Ln(14);
    $pdf->cell(160,6,'',0,0,'R',0);
    $pdf->cell(30,6,'Ttd.',0,1,'L',0);
    $pdf->cell(160,6,'',0,0,'R',0);
    $pdf->cell(30,6,'Panitia Tanwir 1',0,1,'L',0);
    $pdf->Code39(70,102+$tot,$barcode,1.2,10);
    $pdf->cell(62,24.4,'',0,0,'C',0);
    $pdf->cell(70,24.4,'',1,1,'C',0);
    $pdf->Ln(13);
    $pdf->cell(15,6,'',0,0,'C',0);
    $pdf->cell(15,6,'*Note',0,1,'L',0);
    $pdf->cell(15,6,'',0,0,'C',0);
    $pdf->cell(15,6,'1. Panitia tidak menyediakan pengantaran dari bandara menuju lokasi',0,1,'L',0);
    $pdf->cell(15,6,'',0,0,'C',0);
    $pdf->cell(15,6,'2. Panitia stand by di bandara, peserta dapat mendapatkan informasi terkait lokasi',0,1,'L',0);
    $pdf->cell(15,6,'',0,0,'C',0);
    $pdf->cell(15,6,'3. Panitia menyediakan pengantaran pada saat pulang dari lokasi menuju bandara',0,1,'L',0);
    $pdf->cell(15,6,'',0,0,'C',0);
    $pdf->cell(15,6,'4. Panitia hanya bertanggung jawab terhadap akomodasi dan transportasi peserta dari tanggal',0,1,'L',0);
    $pdf->cell(15,6,'',0,0,'C',0);
    $pdf->cell(15,6,'    3-5 November 2017 pukul 14.00',0,1,'L',0);
    $pdf->cell(15,6,'',0,0,'C',0);
    $pdf->cell(15,6,'5. Check in : tanggal 3 November 2017',0,1,'L',0);
    $pdf->cell(15,6,'',0,0,'C',0);
    $pdf->cell(15,6,'    Check out : tanggal 5 November 2017',0,1,'L',0);
    

            // $pdf->cell(42,6,'Kegiatan',1,0,'C',1);
            // $pdf->cell(38,6,'Tanggal Kegiatan',1,1,'C',1);
    $pdf->Output();
?>