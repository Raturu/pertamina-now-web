
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Peserta
      <small>Data peserta TANWIR</small>
    </h1>
    <ol class="breadcrumb">
      <li><i class="fa fa-dashboard"></i> Home</li>
      <li class="active">Peserta</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <?php if($this->session->flashdata('sukses')){ ?>
      <div class="alert alert-success">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo $this->session->flashdata('pesanSukses'); ?>
      </div>
    <?php }elseif ($this->session->flashdata('gagal')) {?>
      <div class="alert alert-danger">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo $this->session->flashdata('pesanGagal'); ?>
      </div>
    <?php } ?>
    <!-- Default box -->
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">Data Peserta</h3>

        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
            <i class="fa fa-minus"></i></button>
        </div>
      </div>
      <div class="box-body">
        <table class="table table-bordered table-hover table-peserta">
          <thead>
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Usia</th>
            <th>Utusan</th>
            <th>Status Verifikasi</th>
            <th>Aksi</th>
          </tr>
          </thead>
        </table>
        <a href="<?=base_url()?>Peserta/cetakSemuaIdCard" target="_blank"><button class="btn btn-success btn-sm pull-left">
          <i class="fa fa-print"></i>
          &nbsp; Cetak semua kartu peserta terverifikasi awal
        </button></a>
        <!-- <button class="btn btn-info pull-right" data-toggle="modal" data-target="#tambahFotoGalery">
          <i class="fa fa-plus"></i>
          &nbsp; Tambah peserta
        </button> -->
      </div>
    </div>

  </section>

  <!--Upload-->
  <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="addMenuTambahan" id="tambahFotoGalery">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Tambah peserta</h4>
        </div>
        <div class="modal-body">
        <form action="<?=base_url()?>Pengguna/addPengguna" method="POST" enctype="multipart/form-data">
          <div class='form-group'>
            <label >Nama</label>
            <p>
              <input type='text' value='' class='form-control' name='nama' required placeholder='Nama'>
            </p>
          </div>
          <div class='form-group'>
            <label >Username</label>
            <p>
              <input type='text' value='' class='form-control' name='username' required placeholder='Username'>
            </p>
          </div>
          <div class='form-group'>
            <label >Password</label>
            <p>
              <input type='password' value='' class='form-control' name='password' required placeholder='Password' id='password'><br>
              <input type='password' value='' class='form-control' required placeholder='Repassword' id='confirm_password'>
            </p>
          </div>
          <div class='form-group'>
            <label >No HP</label>
            <p>
              <input type='text' value='' class='form-control' name='no_hp' required placeholder='Nomor HP'>
            </p>
          </div>
          <div class='form-group'>
            <label >Foto</label>
            <p>
              <input type='file' name='userfile' class='form-control' required>
              <span class='help-block'>Max dimension 165 x 165. Tipe file jpeg | jpg | png</span>
            </p>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Tambah</button>
          <button class="btn btn-default" data-dismiss="modal">Tutup</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  <!-- Detail -->
  <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="addMenuTambahan" id="lihatPeserta">
    <div class="modal-dialog">
      <div class="modal-content" id="modalDetailPeserta">
        
      </div>
    </div>
  </div>

  <!-- Edit -->
  <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="addMenuTambahan" id="editPeserta">
    <div class="modal-dialog">
      <div class="modal-content" id="modalEditPeserta">
        
      </div>
    </div>
  </div>

  <!-- Delete -->
  <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="addMenuTambahan" id="hapusPeserta">
    <div class="modal-dialog">
      <div class="modal-content" id="modalHapusPeserta">
        
      </div>
    </div>
  </div>
</div>