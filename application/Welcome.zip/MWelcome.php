<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MWelcome extends CI_Model {

    function __construct(){
        parent::__construct();
    }

    public function getDataAnggotaByNo($ktna){
        return $this->db->query("select * from anggota where no_anggota='$ktna'");
    }

    public function getAcaraById($id_acara){
        return $this->db->query("SELECT * FROM acara_tanwir where id_acara = '$id_acara'");
    }

    public function getAcara(){
        return $this->db->query("SELECT * FROM acara_tanwir");
    }

    public function getWilayah(){
        $this->db2 = $this->load->database("nasyiah",TRUE);
        return $this->db2->query("select * from wilayah order by wilayah asc");
    }

    public function getPesertaTanwirAbsen($barcode,$id_acara){
        return $this->db->query("SELECT * FROM peserta_tanwir, acara_peserta, peserta_tanwir_absen WHERE peserta_tanwir.id_peserta=acara_peserta.id_peserta and acara_peserta.id_acara_peserta=peserta_tanwir_absen.id_acara_peserta and peserta_tanwir.barcode = '$barcode' and acara_peserta.id_acara='$id_acara'");
    }

    public function getAcaraPesertaByBarcode($barcode,$id_acara){
        return $this->db->query("SELECT * FROM peserta_tanwir, acara_peserta WHERE peserta_tanwir.id_peserta=acara_peserta.id_peserta and peserta.verifikasi = 'Verifikasi Akhir' and peserta_tanwir.barcode = '$barcode' and acara_peserta.id_acara = '$id_acara'");
    }

    public function absen($id_acara_peserta){
        return $this->db->query("INSERT INTO peserta_tanwir_absen(id_acara_peserta,timecreate) VALUES('$id_acara_peserta',now())");
    }

    public function insertAnggota($no_ktna,$nama,$tempat_lahir,$tanggal_lahir,$alamat,$pekerjaan,$wilayah,$no_hp,$email,$pendidikan_terakhir,$namaFoto){
        $this->db->query("INSERT INTO anggota(no_anggota,nama,tanggal_lahir,tempat_lahir,alamat,pekerjaan,no_hp,email,pendidikan_terakhir,wilayah,foto)
            VALUES('".$this->db->escape_str($no_ktna)."','".$this->db->escape_str($nama)."','".$this->db->escape_str($tanggal_lahir)."','".$this->db->escape_str($tempat_lahir)."','".$this->db->escape_str($alamat)."','".$this->db->escape_str($pekerjaan)."','".$this->db->escape_str($no_hp)."','".$this->db->escape_str($email)."','".$this->db->escape_str($pendidikan_terakhir)."','".$this->db->escape_str($wilayah)."','".$this->db->escape_str($namaFoto)."')");
    }

    public function updateAnggota($no_ktna,$nama,$tempat_lahir,$tanggal_lahir,$alamat,$pekerjaan,$wilayah,$no_hp,$email,$pendidikan_terakhir){
        $this->db->query("UPDATE anggota set nama='".$this->db->escape_str($nama)."', tempat_lahir='".$this->db->escape_str($tempat_lahir)."', tanggal_lahir='".$this->db->escape_str($tanggal_lahir)."', alamat='".$this->db->escape_str($alamat)."', pekerjaan='".$this->db->escape_str($pekerjaan)."', wilayah='".$this->db->escape_str($wilayah)."', no_hp='".$this->db->escape_str($no_hp)."', email='".$this->db->escape_str($email)."', pendidikan_terakhir='".$this->db->escape_str($pendidikan_terakhir)."' where no_anggota='".$this->db->escape_str($no_ktna)."'");
    }

    public function getPesertaTanwirByIdPeserta($id_peserta){
        return $this->db->query("SELECT * FROM peserta_tanwir where id_peserta='$id_peserta'");
    }

    public function getAcaraPesertaByIdPeserta($id_peserta){
        return $this->db->query("select at.nama_acara from acara_tanwir at, acara_peserta ap where at.id_acara=ap.id_acara and ap.id_peserta = '$id_peserta' ");
    }

    public function getPesertaTanwirByNoKtna($no_ktna){
        return $this->db->query("SELECT * FROM peserta_tanwir where no_ktna='$no_ktna'");
    }

    public function insertPesertaTanwir($no_ktna,$nama,$tanggal_lahir,$tempat_lahir,$alamat,$pekerjaan,$no_hp,$email,$pendidikan_terakhir,$wilayah,$namaFoto,$barcode,$tahun_aktif,$jumlah_anak_dibawa,$tanggal_datang,$jam_datang,$tanggal_pulang,$jam_pulang){
        $this->db->query("INSERT INTO peserta_tanwir(no_ktna,nama,tanggal_lahir,tempat_lahir,alamat,pekerjaan,no_hp,email,pendidikan_terakhir,wilayah,foto,barcode,tahun_aktif,jumlah_anak_dibawa,tanggal_datang,jam_datang,tanggal_pulang,jam_pulang)
            VALUES('".$this->db->escape_str($no_ktna)."','".$this->db->escape_str($nama)."','".$this->db->escape_str($tanggal_lahir)."','".$this->db->escape_str($tempat_lahir)."','".$this->db->escape_str($alamat)."','".$this->db->escape_str($pekerjaan)."','".$this->db->escape_str($no_hp)."','".$this->db->escape_str($email)."','".$this->db->escape_str($pendidikan_terakhir)."','".$this->db->escape_str($wilayah)."','".$this->db->escape_str($namaFoto)."','".$this->db->escape_str($barcode)."','".$this->db->escape_str($tahun_aktif)."','".$this->db->escape_str($jumlah_anak_dibawa)."','".$this->db->escape_str($tanggal_datang)."','".$this->db->escape_str($jam_datang)."','".$this->db->escape_str($tanggal_pulang)."','".$this->db->escape_str($jam_pulang)."')");
    }

    public function insertOrganisasi($id_peserta, $organisasi){

        $this->db->query("INSERT INTO organisasi(id_peserta) VALUES('$id_peserta')");
        $i = 0;
        while($i < count($organisasi)){
            if($organisasi[$i] == "IPM / IRM"){
                $this->db->query("UPDATE organisasi set IPM_IRM = TRUE where id_peserta = '$id_peserta'");
            }elseif($organisasi[$i] == "IMM"){
                $this->db->query("UPDATE organisasi set IMM = TRUE where id_peserta = '$id_peserta'");
            }else{
                $this->db->query("UPDATE organisasi set lainnya = '".$organisasi[$i]."' where id_peserta = '$id_peserta'");
            }
            $i++;
        }
    }

    public function insertAcara($id_peserta,$acara_dipilih){
        $i = 0;
        while($i < count($acara_dipilih)){
            $this->db->query("INSERT INTO acara_peserta(id_peserta,id_acara,timecreate) VALUES('$id_peserta','$acara_dipilih[$i]',now())");
            $i++;
        }
    }

    public function insertPelatihanKader($id_peserta,$pelatihan){
        $this->db->query("INSERT INTO pelatihan_kader(id_peserta) VALUES ('$id_peserta')");
        $i=0;
        while ($i < count($pelatihan)) {
            if($pelatihan[$i] == "Taruna Melati 1"){
                $this->db->query("UPDATE pelatihan_kader set taruna_melati_1 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "Taruna Melati 2") {
                $this->db->query("UPDATE pelatihan_kader set taruna_melati_2 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "Taruna Melati 3") {
                $this->db->query("UPDATE pelatihan_kader set taruna_melati_3 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "TM Utama") {
                $this->db->query("UPDATE pelatihan_kader set tm_utama = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "DAD") {
                $this->db->query("UPDATE pelatihan_kader set DAD = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "DAM") {
                $this->db->query("UPDATE pelatihan_kader set DAM = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "DAP") {
                $this->db->query("UPDATE pelatihan_kader set DAP = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "LT 1") {
                $this->db->query("UPDATE pelatihan_kader set LT_1 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "LT 2") {
                $this->db->query("UPDATE pelatihan_kader set LT_2 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "LINA I") {
                $this->db->query("UPDATE pelatihan_kader set LINA_1 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "LINA II") {
                $this->db->query("UPDATE pelatihan_kader set LINA_2 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "DANA I") {
                $this->db->query("UPDATE pelatihan_kader set DANA_1 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "DANA II") {
                $this->db->query("UPDATE pelatihan_kader set DANA_2 = TRUE where id_peserta = '$id_peserta' ");
            }elseif ($pelatihan[$i] == "DANA III") {
                $this->db->query("UPDATE pelatihan_kader set DANA_3 = TRUE where id_peserta = '$id_peserta' ");
            }
            $i++;
        }
    }

    public function insertInformasi($id_peserta,$informasi){
        $this->db->query("INSERT INTO informasi(id_peserta) VALUES ('$id_peserta')");
        $i=0;
        while ($i < count($informasi)) {
            if($informasi[$i] == "Dalam keadaan sehat bugar"){
                $this->db->query("UPDATE informasi set dalam_keadaan_sehat_bugar = TRUE where id_peserta = '$id_peserta'");
            }elseif($informasi[$i] == "Dalam masa pemulihan pasca sakit / kecelakaan"){
                $this->db->query("UPDATE informasi set dalam_masa_pemulihan_pasca_sakit_kecelakaan = TRUE where id_peserta = '$id_peserta'");
            }elseif($informasi[$i] == "Membawa pengasuh untuk anak"){
                $this->db->query("UPDATE informasi set membawa_pengasuh_untuk_anak = TRUE where id_peserta = '$id_peserta'");
            }elseif($informasi[$i] == "Sedang hamil atau menyusui"){
                $this->db->query("UPDATE informasi set sedang_hamil_atau_menyusui = TRUE where id_peserta = '$id_peserta'");
            }
            $i++;
        }
    }

    public function getMaxIdPesertaDesc(){
        return $this->db->query("select id_peserta from peserta_tanwir order by id_peserta desc limit 1");
    }
}