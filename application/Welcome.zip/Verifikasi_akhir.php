<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

include_once(APPPATH.'core/Admin_Controller.php');

class Verifikasi_akhir extends Admin_Controller {
  function __construct()
  {
    parent::__construct();
    if($this->session->userdata('id_pengguna') == ""){
      redirect('Auth');
    }
    $this->load->model("MVerifikasi");
  }

  public function index() {
    $this->data['current_page'] = $this->uri->uri_string();
    $this->data['wilayah'] = $this->MVerifikasi->getWilayah();
    $this->content = 'admin/verifikasi_akhir'; 
    $this->navigation = 'template_admin/_parts/navigation/admin_view'; 
    // passing middle to function. change this for different views.
    $this->data['page_title'] = 'Verifikasi Akhir | TANWIR';
    $this->layout();
  }


  public function getData(){
    $this->data['current_page'] = $this->uri->uri_string();
    $this->data['wilayah'] = $this->MVerifikasi->getWilayah();
    if($this->input->post('nama') != null){
      $this->data['wilayahPilih'] = $wilayahPilih = $this->input->post('wilayah');
      $this->data['namaPilih'] = $namaPilih = $this->input->post('nama');
    }else{
      $this->data['wilayahPilih'] = $wilayahPilih = str_replace("%20", " ", $this->uri->segment(4));
      $this->data['namaPilih'] = $namaPilih = $this->uri->segment(3);
    }
    $this->data['peserta_tanwir'] = $this->MVerifikasi->getDataPesertaTanwirByNamaWilayah($wilayahPilih,$namaPilih);
    $this->content = 'admin/verifikasi_akhir'; 
    $this->navigation = 'template_admin/_parts/navigation/admin_view'; 
    // passing middle to function. change this for different views.
    $this->data['page_title'] = 'Verifikasi Akhir | TANWIR';
    $this->layout();
  }

  public function submit(){
    $this->MVerifikasi->updateVerfikasiAkhir($this->input->post('id_peserta'));
    $this->session->set_flashdata('sukses',true);
    $this->session->set_flashdata('pesanSukses','<h4><i class="fa fa-check"></i> Sukses!</h4><p>Peserta berhasil verifikasi akhir!</p>');
    redirect('Verifikasi_akhir/getData/'.$this->input->post('namaPilih')."/".$this->input->post('wilayahPilih'),'refresh');
  }
}