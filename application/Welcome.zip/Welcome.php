<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends My_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct()
	{
		parent::__construct();
		$this->load->model("MWelcome");
		$this->load->library('fpdf');
		$this->load->library('PDF_Code39');
	}

	public function index()
	{

		$this->data['current_page'] = $this->uri->uri_string();
		$this->data['wilayah'] = $this->MWelcome->getWilayah();
		$this->data['acara_tanwir'] = $this->MWelcome->getAcara();
		$this->navigation = 'template/_parts/navigation/navigation_view';
		$this->content = 'form_pendaftaran'; 
	    // passing middle to function. change this for different views.
		$this->data['page_title'] = 'Tanwir | Nasyiatul Aisyiyah';
		$this->layout();
	}

	public function absen($id_acara){
		foreach ($this->MWelcome->getAcaraById($id_acara)->result() as $value) {
			$data['acara'] = $value->nama_acara;
			$data['id_acara'] = $value->id_acara;
		}
		$this->load->view('halaman_absen/halaman_absen',$data);
	}

	public function scan(){
	    $id_acara = $this->input->post('id_acara');
	    $data['id_acara'] = $id_acara;
	    if($this->MWelcome->getPesertaTanwirAbsen($this->input->post('barcode'),$id_acara)->num_rows() == null){
	      $peserta = $this->MWelcome->getAcaraPesertaByBarcode($this->input->post('barcode'),$id_acara);
	      if($peserta->num_rows() > 0){
	        foreach ($peserta->result() as $key) {
	          $data['nama'] = $key->nama;
	          $data['utusan'] = $key->wilayah;
	          $id_acara_peserta = $key->id_acara_peserta;
	        }
	        $this->MWelcome->absen($id_acara_peserta);
	        $this->load->view('halaman_absen/sukses',$data);
	      }else{
	        $this->load->view('halaman_absen/gagal',$data);
	      }
	    }else{
	      $this->load->view('halaman_absen/gagal',$data);
	    }
	}

	public function cetak(){
		$data['data'] = $this->MWelcome->getPesertaTanwirByIdPeserta($this->uri->segment(3));
		$data['acara'] = $this->MWelcome->getAcaraPesertaByIdPeserta($this->uri->segment(3));
		$this->load->view('cetakBuktiPendaftaran',$data);
	}

	public function register(){
		$this->data['no_ktna'] = $no_ktna = $this->input->post('no_ktna');
		$dataPesertaTanwir = $this->MWelcome->getPesertaTanwirByNoKtna($no_ktna);
		// peserta tanwir has been registered or not
		if($dataPesertaTanwir->num_rows() == null){
			$this->data['nama'] = $nama = $this->input->post('nama');
			$this->data['tempat_lahir'] = $tempat_lahir = $this->input->post('tempat_lahir');
			$this->data['tanggal_lahir'] = $tanggal_lahir = $this->input->post('tanggal_lahir');
			$this->data['alamat'] = $alamat = $this->input->post('alamat');
			$this->data['pekerjaan'] = $pekerjaan = $this->input->post('pekerjaan');
			$this->data['no_hp'] = $no_hp = $this->input->post('no_hp');
			$this->data['email'] = $email = $this->input->post('email');
			$this->data['pendidikan_terakhir'] = $pendidikan_terakhir = $this->input->post('pendidikan_terakhir');
			$this->data['wilayahA'] = $wilayah = $this->input->post('wilayah');
			$userfile = $this->input->post('userfile');
			$this->data['organisasi'] = $organisasi = $this->input->post('organisasi');
			$this->data['tahun_aktif'] = $tahun_aktif = $this->input->post('tahun_aktif');
			$this->data['pelatihan'] = $pelatihan = $this->input->post('pelatihan');
			$this->data['acara'] = $acara = $this->input->post('acara');
			$this->data['tanggal_datang'] = $tanggal_datang = $this->input->post('tanggal_datang');
			$this->data['jam_datang'] = $jam_datang = $this->input->post('jam_datang');
			$this->data['tanggal_pulang'] = $tanggal_pulang = $this->input->post('tanggal_pulang');
			$this->data['jam_pulang'] = $jam_pulang = $this->input->post('jam_pulang');
			$this->data['jumlah_anak_dibawa'] = $jumlah_anak_dibawa = $this->input->post('jumlah_anak_dibawa');
			$this->data['informasi'] = $informasi = $this->input->post('informasi');

			$hasilUpload = $this->uploadFoto($userfile);
			if($hasilUpload == true){
				// Generate barcode dan memastikan barcode yang dibuat belum ada di peserta_tanwir
				$barcode = rand(1000000, 9999999);
				$cekBarcode = $this->db->query("select * from peserta_tanwir where barcode='$barcode'");
				while ($cekBarcode->num_rows() != null) {
					$barcode = rand(1000000, 9999999);
					$cekBarcode = $this->db->query("select * from peserta_tanwir where barcode='$barcode'");
				}

				$fotoUpload = $this->upload->data();
				$namaFoto = $fotoUpload['file_name'];

				$dataAnggota = $this->MWelcome->getDataAnggotaByNo($no_ktna);
				if($dataAnggota->num_rows() >= 1){
					$this->MWelcome->updateAnggota($no_ktna,$nama,$tempat_lahir,$tanggal_lahir,$alamat,$pekerjaan,$wilayah,$no_hp,$email,$pendidikan_terakhir);
				}

				$this->MWelcome->insertPesertaTanwir($no_ktna,$nama,$tanggal_lahir,$tempat_lahir,$alamat,$pekerjaan,$no_hp,$email,$pendidikan_terakhir,$wilayah,$namaFoto,$barcode,$tahun_aktif,$jumlah_anak_dibawa,$tanggal_datang,$jam_datang,$tanggal_pulang,$jam_pulang);

				$pesertaTanwir = $this->MWelcome->getMaxIdPesertaDesc();
				foreach ($pesertaTanwir->result() as $key) {
					$id_peserta = $key->id_peserta;
				}

				$this->MWelcome->insertOrganisasi($id_peserta,$organisasi);
				$this->MWelcome->insertAcara($id_peserta,$acara);
				$this->MWelcome->insertPelatihanKader($id_peserta,$pelatihan);
				$this->MWelcome->insertInformasi($id_peserta,$informasi);

				$this->session->set_flashdata('sukses',true);
				$this->session->set_flashdata('pesanSukses','<h4><i class="fa fa-check"></i> Berhasil!</h4><p>Pendaftaran berhasil dilakukan!</p><p>Cetak bukti pendaftaran <a href="'.base_url().'Welcome/cetak/'.$id_peserta.'" target="_blank"><b>cetak</b></a></p>');
				redirect('Welcome','refresh');
			}else{
				$this->session->set_flashdata('sukses',false);
				$this->session->set_flashdata('gagal',true);
				$this->session->set_flashdata('pesanGagal','<h4><i class="fa fa-times"></i> Gagal!</h4><p>Pendaftaran gagal dilakukan!</p><p>Foto : '.$this->upload->display_errors().'</p>');
				$this->index();
			}
		}else{
			foreach ($dataPesertaTanwir->result() as $value) {
				$id_peserta = $value->id_peserta;
			}
			$this->session->set_flashdata('sukses',false);
			$this->session->set_flashdata('gagal',true);
			$this->session->set_flashdata('pesanGagal','<h4><i class="fa fa-times"></i> Gagal!</h4><p>Pendaftaran gagal dilakukan!</p><p>Anda sudah mendaftar dengan No KTNA '.$no_ktna.'</p><p>Cetak bukti pendaftaran <a href="'.base_url().'Welcome/cetak/'.$id_peserta.'" target="_blank"><b>cetak</b></a></p>');
			$this->index();
		}
	}

	public function uploadFoto($userfile){
		$config['upload_path'] = './assets/dist/img/peserta/';
		$config['allowed_types'] = 'png|jpg';
		$config['max_size'] = '1000';
		$config['max_width']  = '215';
		$config['max_height']  = '215';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('userfile')){
			$hasil = false;
			return $hasil;
		}else{
			$hasil = true;
			return $hasil;
		}
	}

	public function cari_data_peserta_ajax(){
		$peserta = $this->MWelcome->getPesertaTanwirByNoKtna($this->input->post('no_ktna'));
		if($peserta->num_rows() > 0){
			foreach ($peserta->result() as $key) {
				$data = array(
					'id_peserta' => $key->id_peserta
				);
			}
		}
		echo json_encode($data);
	}

	public function cari_data_no_ktna_ajax(){
		$anggota = $this->MWelcome->getDataAnggotaByNo($this->input->post('no_ktna'));
		if($anggota->num_rows() > 0){
			foreach ($anggota->result() as $key) {
				$data = array(
					'nama' => $key->nama,
					'tempat_lahir' => $key->tempat_lahir,
					'tanggal_lahir' => $key->tanggal_lahir,
					'alamat' => $key->alamat,
					'pekerjaan' => $key->pekerjaan,
					'no_hp' => $key->no_hp,
					'email' => $key->email,
					'pendidikan_terakhir' => $key->pendidikan_terakhir,
					'wilayah' => $key->wilayah
					);
			}
		}
		// else{
		// 	$data = array(
		// 		'nama' => "Tidak ada data",
		// 		'tempat_lahir' => "Tidak ada data"
		// 	);
		// }
		
		echo json_encode($data);
	}
}
