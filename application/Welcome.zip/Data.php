<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

include_once(APPPATH.'core/Admin_Controller.php');

class Data extends Admin_Controller {
    function __construct()
  {
    parent::__construct();
    $this->load->model("MData");
  }


  public function getDataFilterPeserta(){
    $informasi = $this->uri->segment(3);
    /*Menagkap semua data yang dikirimkan oleh client*/

    /*Sebagai token yang yang dikrimkan oleh client, dan nantinya akan
    server kirimkan balik. Gunanya untuk memastikan bahwa user mengklik paging
    sesuai dengan urutan yang sebenarnya */
    $draw=$_REQUEST['draw'];

    /*Jumlah baris yang akan ditampilkan pada setiap page*/
    $length=$_REQUEST['length'];

    /*Offset yang akan digunakan untuk memberitahu database
    dari baris mana data yang harus ditampilkan untuk masing masing page
    */
    $start=$_REQUEST['start'];

    /*Keyword yang diketikan oleh user pada field pencarian*/
    $search=$_REQUEST['search']["value"];


    /*Menghitung total berita didalam database*/
    $this->db->select("*");
    $this->db->from("peserta_tanwir p");
    $this->db->join("informasi i","p.id_peserta=i.id_peserta");
    if($informasi != ""){
        $this->db->where($informasi,"1");
    }else{
        $this->db->where("dalam_keadaan_sehat_bugar","2");
    }
    $total=$this->db->count_all_results();

    /*Mempersiapkan array tempat kita akan menampung semua data
    yang nantinya akan server kirimkan ke client*/
    $output=array();

    /*Token yang dikrimkan client, akan dikirim balik ke client*/
    $output['draw']=$draw;

    /*
    $output['recordsTotal'] adalah total data sebelum difilter
    $output['recordsFiltered'] adalah total data ketika difilter
    Biasanya kedua duanya bernilai sama, maka kita assignment 
    keduaduanya dengan nilai dari $total
    */
    $output['recordsTotal']=$output['recordsFiltered']=$total;

    /*disini nantinya akan memuat data yang akan kita tampilkan 
    pada table client*/
    $output['data']=array();


    /*Jika $search mengandung nilai, berarti user sedang telah 
    memasukan keyword didalam filed pencarian*/
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("no_ktna",$search);
    $this->db->or_like("pekerjaan",$search);
    $this->db->or_like("no_hp",$search);
    $this->db->or_like("pendidikan_terakhir",$search);
    $this->db->or_like("wilayah",$search);
    }


    /*Lanjutkan pencarian ke database*/
    $this->db->limit($length,$start);
    /*Urutkan dari alphabet paling terkahir*/
    // $this->db->order_by('nama','desc');
    $this->db->select("*");
    $this->db->from("peserta_tanwir p");
    $this->db->join("informasi i","p.id_peserta=i.id_peserta");
    if($informasi != ""){
        $this->db->where($informasi,"1");
    }else{
        $this->db->where("dalam_keadaan_sehat_bugar","2");
    }
    $query=$this->db->get();


    /*Ketika dalam mode pencarian, berarti kita harus mengatur kembali nilai 
    dari 'recordsTotal' dan 'recordsFiltered' sesuai dengan jumlah baris
    yang mengandung keyword tertentu
    */
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("no_ktna",$search);
    $this->db->or_like("pekerjaan",$search);
    $this->db->or_like("no_hp",$search);
    $this->db->or_like("pendidikan_terakhir",$search);
    $this->db->or_like("wilayah",$search);

    $this->db->select("*");
    $this->db->from("peserta_tanwir p");
    $this->db->join("informasi i","p.id_peserta=i.id_peserta");
    if($informasi != ""){
        $this->db->where($informasi,"1");
    }else{
        $this->db->where("dalam_keadaan_sehat_bugar","2");
    }
    $jum=$this->db->get();
    $output['recordsTotal']=$output['recordsFiltered']=$jum->num_rows();
    }

    $this->db->select("*");
    $this->db->from("peserta_tanwir p");
    $this->db->join("informasi i","p.id_peserta=i.id_peserta");
    if($informasi != ""){
        $this->db->where($informasi,"1");
    }else{
        $this->db->where("dalam_keadaan_sehat_bugar","2");
    }
    $tot=$this->db->get(); 


    $nomor_urut=$start+1;
    foreach ($query->result_array() as $peserta_tanwir) {
        $output['data'][]=array(
          $nomor_urut,
          $peserta_tanwir['nama'],
          $peserta_tanwir['wilayah'],
          $peserta_tanwir['tanggal_datang']." ".$peserta_tanwir['jam_datang'],
          $peserta_tanwir['tanggal_pulang']." ".$peserta_tanwir['jam_pulang'],
          $peserta_tanwir['jumlah_anak_dibawa'],
          $peserta_tanwir['verifikasi'],
          "<button class='btn btn-xs btn-info detail-peserta' data-id='".$peserta_tanwir['id_peserta']."'><i class='fa fa-info'></i>&nbsp; Detail</button>
          <button class='btn btn-xs btn-warning edit-filter-peserta' data-id2='".$informasi."' data-id='".$peserta_tanwir['id_peserta']."'><i class='fa fa-pencil'></i>&nbsp; Edit</button>
            <button class='btn btn-xs btn-danger hapus-filter-peserta' data-id2='".$informasi."' data-id='".$peserta_tanwir['id_peserta']."'><i class='fa fa-trash'></i>&nbsp; Hapus</button>");
        $nomor_urut++;
    }
    echo json_encode($output);
  }

  public function modalEditFilterPeserta(){
    foreach ($this->MData->getDataPesertaById($_POST['id'])->result() as $key) {
        $nama = $key->nama;
        $no_ktna = $key->no_ktna;
        $tanggal_lahir = $key->tanggal_lahir;
        $tempat_lahir = $key->tempat_lahir;
        $alamat = $key->alamat;
        $pekerjaan = $key->pekerjaan;
        $no_hp = $key->no_hp;
        $email = $key->email;
        $pendidikan_terakhir = $key->pendidikan_terakhir;
        $wilayah = $key->wilayah;
        $foto = $key->foto;
        $tahun_aktif = $key->tahun_aktif;
        $jumlah_anak_dibawa = $key->jumlah_anak_dibawa;
        $tanggal_datang = $key->tanggal_datang;
        $jam_datang = $key->jam_datang;
        $tanggal_pulang = $key->tanggal_pulang;
        $jam_pulang = $key->jam_pulang;
    }
    $organisasi = $this->MData->getOrganisasiByIdPeserta($_POST['id']);
    $hasilOrganisasi = "";
    foreach ($organisasi->result() as $value) {
      if($value->IPM_IRM == 1){
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='IPM / IRM' class='form-check-input' checked> IPM / IRM ";
      }else{
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='IPM / IRM' class='form-check-input'> IPM / IRM ";
      }
      if($value->IMM == 1){
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='IMM' lass='form-check-input' checked> IMM <br>";
      }else{
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='IMM' lass='form-check-input'> IMM <br>";
      }
      if($value->lainnya != ""){
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='Lainnya' class='form-check-input' checked> Lainnya";
        $hasilOrganisasi = $hasilOrganisasi."<textarea class='form-control' rows='2' name='organisasi[]' placeholder='Sebutkan'>".$value->lainnya."</textarea>";
      }else{
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='Lainnya' class='form-check-input'> Lainnya";
        $hasilOrganisasi = $hasilOrganisasi."<textarea class='form-control' rows='2' name='organisasi[]' placeholder='Sebutkan'></textarea>";
      }
    }

    $informasi = $this->MData->getInformasiByIdPeserta($_POST['id']);

    $hasilInformasi = "";
    foreach ($informasi->result() as $value) {
      if($value->dalam_keadaan_sehat_bugar == 1){
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi1' value='Dalam keadaan sehat bugar' class='form-check-input' checked> Dalam keadaan sehat bugar <br>";
      }else{
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi1' value='Dalam keadaan sehat bugar' class='form-check-input'> Dalam keadaan sehat bugar <br>";
      }
      if($value->dalam_masa_pemulihan_pasca_sakit_kecelakaan == 1){
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi2' value='Dalam masa pemulihan pasca sakit / kecelakaan' class='form-check-input' checked> Dalam masa pemulihan pasca sakit / kecelakaan <br>";
      }else{
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi2' value='Dalam masa pemulihan pasca sakit / kecelakaan' class='form-check-input'> Dalam masa pemulihan pasca sakit / kecelakaan <br>";
      }
      if($value->membawa_pengasuh_untuk_anak == 1){
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi3' value='Membawa pengasuh untuk anak' class='form-check-input' checked> Membawa pengasuh untuk anak <br>";
      }else{
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi3' value='Membawa pengasuh untuk anak' class='form-check-input'> Membawa pengasuh untuk anak <br>";
      }
      if($value->sedang_hamil_atau_menyusui == 1){
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi4' value='Sedang hamil atau menyusui' class='form-check-input' checked> Sedang hamil atau menyusui";
      }else{
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi4' value='Sedang hamil atau menyusui' class='form-check-input'> Sedang hamil atau menyusui";
      }
    }

    $acaraPeserta = $this->MData->getAcaraByIdPeserta($_POST['id']);
    $acara = $this->MData->getAcara();
    $hasilAcara = "";
    foreach ($acara->result() as $value) {
        $hasilAcara = $hasilAcara."<input type='checkbox' name='acara[]' value='".$value->id_acara."' class='form-check-input'";
        foreach ($acaraPeserta->result() as $key) {
          if($value->id_acara == $key->id_acara){
            $hasilAcara = $hasilAcara."checked";
          }
        }
        $hasilAcara = $hasilAcara.">".$value->nama_acara." <br>";
    }
    

    $pelatihan_kader = $this->MData->getPelatihanKaderByIdPeserta($_POST['id']);
    $hasilPelatihanKader = "<table style='width:50%;'><tr><td>";
    foreach ($pelatihan_kader->result() as $value) {
      if($value->taruna_melati_1 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 1' class='form-check-input' checked> Taruna Melati 1</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 1' class='form-check-input'> Taruna Melati 1</td><td>";
      }
      if($value->DAD == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAD' class='form-check-input' checked> DAD</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAD' class='form-check-input'> DAD</td><td>";
      }
      if($value->LT_1 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LT 1' class='form-check-input' checked> LT 1</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LT 1' class='form-check-input'> LT 1</td><td>";
      }
      if($value->LINA_1 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LINA I' class='form-check-input' checked> LINA I</td></tr><tr><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LINA I' class='form-check-input'> LINA I</td></tr><tr><td>";
      }
      if($value->taruna_melati_2 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 2' class='form-check-input' checked> Taruna Melati 2</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 2' class='form-check-input'> Taruna Melati 2</td><td>";
      }
      if($value->DAM == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAM' class='form-check-input' checked> DAM</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAM' class='form-check-input'> DAM</td><td>";
      }
      if($value->LT_2 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LT 2' class='form-check-input' checked> LT 2</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LT 2' class='form-check-input'> LT 2</td><td>";
      }
      if($value->LINA_2 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LINA II' class='form-check-input' checked> LINA II</td></tr><tr><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LINA II' class='form-check-input'> LINA II</td></tr><tr><td>";
      }
      if($value->taruna_melati_3 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 3' class='form-check-input' checked> Taruna Melati 3</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 3' class='form-check-input'> Taruna Melati 3</td><td>";
      }
      if($value->DAP == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAP' class='form-check-input' checked> DAP</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAP' class='form-check-input'> DAP</td><td>";
      }
      if($value->DANA_1 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA I' class='form-check-input' checked> DANA I</td></tr><tr><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA I' class='form-check-input'> DANA I</td></tr><tr><td>";
      }
      if($value->tm_utama == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='TM Utama' class='form-check-input' checked> TM Utama</td><td></td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='TM Utama' class='form-check-input'> TM Utama</td><td></td><td>";
      }
      if($value->DANA_2 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA II' class='form-check-input' checked> DANA II</td></tr><tr><td></td><td></td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA II' class='form-check-input'> DANA II</td></tr><tr><td></td><td></td><td>";
      }
      if($value->DANA_3 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA III' class='form-check-input' checked> DANA III</td></tr></table>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA III' class='form-check-input'> DANA III</td></tr></table>";
      }
    }
    

    $hasilPekerjaan = "<select name='pekerjaan' class='form-control' required>
                <option value=''>-- Pilih pekerjaan --</option>";
    if($pekerjaan == "Pelajar"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Pelajar' selected>Pelajar</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Pelajar'>Pelajar</option>";
    }
    if($pekerjaan == "Mahasiswa"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Mahasiswa' selected>Mahasiswa</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Mahasiswa'>Mahasiswa</option>";
    }
    if($pekerjaan == "PNS"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='PNS' selected>PNS</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='PNS'>PNS</option>";
    }
    if($pekerjaan == "Swasta"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Swasta' selected>Swasta</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Swasta'>Swasta</option>";
    }
    if($pekerjaan == "Ibu rumah tangga"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Ibu rumah tangga' selected>Ibu rumah tangga</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Ibu rumah tangga'>Ibu rumah tangga</option>";
    }
    if($pekerjaan == "Dosen"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Dosen' selected>Dosen</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Dosen'>Dosen</option>";
    }
    if($pekerjaan == "Guru"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Guru' selected>Guru</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Guru'>Guru</option>";
    }
    $hasilPekerjaan = $hasilPekerjaan."</select>";
                
    $hasilPendidikanTerakhir = "<select name='pendidikan_terakhir' class='form-control' required>
                <option value=''>-- Pendidikan terakhir --</option>";
    if($pendidikan_terakhir == "SMA/SMK"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='SMA/SMK' selected>SMA/SMK</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='SMA/SMK'>SMA/SMK</option>";
    }
    if($pendidikan_terakhir == "D1"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D1' selected>D1</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D1'>D1</option>";
    }
    if($pendidikan_terakhir == "D3"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D3' selected>D3</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D3'>D3</option>";
    }
    if($pendidikan_terakhir == "D4"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D4' selected>D4</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D4'>D4</option>";
    }
    if($pendidikan_terakhir == "S1"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S1' selected>S1</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S1'>S1</option>";
    }
    if($pendidikan_terakhir == "S2"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S2' selected>S2</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S2'>S2</option>";
    }
    if($pendidikan_terakhir == "S3"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S3' selected>S3</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S3'>S3</option>";
    }
    $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."</select>";


              
      
    echo "<div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
            <span aria-hidden='true'>&times;</span></button>
            <h4 class='modal-title'>Edit Data Peserta</h4>
        </div>
        <div class='modal-body'>
          <form action='".base_url()."Filter_peserta/editPeserta' method='POST' enctype='multipart/form-data'>
          <input type='hidden' name='id_peserta' value='".$_POST['id']."'>
          <input type='hidden' name='foto' value='".$foto."'>
          <input type='hidden' name='no_ktnaAwal' value='".$no_ktna."'>
          <input type='hidden' name='informasiDipilih' value='".$_POST['informasi']."'>
          <div class='form-group'>
            <label >No. KTNA</label>
            <p>
              <input type='text' value='".$no_ktna."' class='form-control' name='no_ktna' required placeholder='Nama'>
            </p>
          </div>
          <div class='form-group'>
            <label >Nama</label>
            <p>
              <input type='text' value='".$nama."' class='form-control' name='nama' required placeholder='Nama'>
            </p>
          </div>
          <div class='form-group'>
            <label >Tempat Lahir</label>
            <p>
              <input type='text' value='".$tempat_lahir."' class='form-control' name='tempat_lahir' required placeholder='Username'>
            </p>
          </div>
          <div class='form-group'>
            <label >Tanggal Lahir</label>
            <p>
              <input type='date' value='".$tanggal_lahir."' class='form-control' name='tanggal_lahir' required placeholder='Username'>
              <span class='help-block'>Format tanggal 20/12/2017</span>
            </p>
          </div>
          <div class='form-group'>
            <label>Alamat</label>
            <p>
              <textarea name='alamat' class='form-control' rows='2'>".$alamat."</textarea>
            </p>
          </div>
          <div class='form-group'>
            <label>Pekerjaan</label>
            <p>
              ".$hasilPekerjaan."
            </p>
          </div>
          <div class='form-group'>
            <label >No HP</label>
            <p>
              <input type='text' value='".$no_hp."' class='form-control' name='no_hp' required placeholder='Nomor telepon'>
            </p>
          </div>
          <div class='form-group'>
            <label>Email</label>
            <p>
              <input type='text' value='".$email."' class='form-control' name='email' required placeholder='Nomor telepon'>
            </p>
          </div>
          <div class='form-group'>
            <label>Pendidikan Terakhir</label>
            <p>
              ".$hasilPendidikanTerakhir."
            </p>
          </div>
          <div class='form-group'>
            <label >Utusan</label>
            <p>
              <input type='text' value='".$wilayah."' class='form-control' name='wilayah' required placeholder='Utusan'>
            </p>
          </div>
          <div class='form-group'>
            <label >Foto</label>
            <p>
              <input type='file' name='userfile' class='form-control' required>
              <span class='help-block'>Max dimension 215 x 215. Tipe file jpg | png</span>
            </p>
          </div>
          <div class='form-group'>
            <label>Organisasi yang diikuti sebelum NA</label>
            <p>
              ".$hasilOrganisasi."
            </p>
          </div>
          <div class='form-group'>
            <label>Tahun Aktif di NA</label>
            <p>
              <input type='number' value='".$tahun_aktif."' class='form-control' name='tahun_aktif' required placeholder='Tahun Aktif'>
            </p>
          </div>
          <div class='form-group'>
            <label>Pelatihan Perkaderan yang Pernah Diikuti</label>
            <p>
              ".$hasilPelatihanKader."
            </p>
          </div>
          <div class='form-group'>
            <label>Acara yang Diikuti dalam TANWIR</label>
            <p>
              ".$hasilAcara."
            </p>
          </div>
          <div class='form-group'>
            <label>Tanggal Datang</label>
            <p>
              <input type='date' value='".$tanggal_datang."' class='form-control' name='tanggal_datang' required>
              <span class='help-block'>Format tanggal 20/12/2017</span>
            </p>
          </div>
          <div class='form-group'>
            <label>Jam Datang</label>
            <p>
              <input type='time' value='".$jam_datang."' class='form-control' name='jam_datang' required>
            </p>
          </div>
          <div class='form-group'>
            <label>Tanggal Pulang</label>
            <p>
              <input type='date' value='".$tanggal_pulang."' class='form-control' name='tanggal_pulang' required>
              <span class='help-block'>Format tanggal 20/12/2017</span>
            </p>
          </div>
          <div class='form-group'>
            <label>Jam Pulang</label>
            <p>
              <input type='time' value='".$jam_pulang."' class='form-control' name='jam_pulang' required>
            </p>
          </div>
          <div class='form-group'>
            <label>Jumlah Anak yang Dibawa</label>
            <p>
              <input type='number' value='".$jumlah_anak_dibawa."' class='form-control' name='jumlah_anak_dibawa' required>
            </p>
          </div>
          <div class='form-group'>
            <label>Infromasi lain (Wajib diisi, bisa dipilih lebih dari satu)</label>
            <span class='help-block'>(Boleh lebih dari 1)</span>
            <p>
              ".$hasilInformasi."
            </p>
          </div>
          <button type='submit' class='btn btn-success'>Submit</button>
          </form>
        </div>

        <script>//re password validation
        var password = document.getElementById('password".$_POST['id']."'), confirm_password = document.getElementById('confirm_password".$_POST['id']."');

        function validatePassword(){
          if(password.value != confirm_password.value) {
            confirm_password".$_POST['id'].".setCustomValidity('Password does not match');
          } else {
            confirm_password".$_POST['id'].".setCustomValidity('');
          }
        }

        password".$_POST['id'].".onchange = validatePassword;
        confirm_password".$_POST['id'].".onkeyup = validatePassword;</script>
        ";
  }

  public function modalHapusFilterPeserta(){
    foreach ($this->MData->getDataPesertaById($_POST['id'])->result() as $key) {
        $nama = $key->nama;
        $foto = $key->foto;
    }

    echo "<div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal'><span aria-hidden='true'>&times;</span><span class='sr-only'>Close</span></button>
            <h4 class='modal-title' id='myModalLabel'>Hapus data peserta</h4>
          </div>
          <div class='modal-body'>
              Hapus data ".$nama." ?
           </div>
           <div class='modal-footer'>
              <button type='button' class='btn btn-default' data-dismiss='modal'>Tidak</button>
              <a href='".base_url()."Filter_peserta/hapusPeserta/".$_POST['id']."/".$foto."/".$_POST['informasi']."'><button type='button' id='confirmHapus' class='simpan btn btn-primary'>Ya</button></a>
           </div>";
  }









  public function getDataVerifikasiAwal(){
    $wilayah = str_replace("%20", " ", $this->uri->segment(3));
    /*Menagkap semua data yang dikirimkan oleh client*/

    /*Sebagai token yang yang dikrimkan oleh client, dan nantinya akan
    server kirimkan balik. Gunanya untuk memastikan bahwa user mengklik paging
    sesuai dengan urutan yang sebenarnya */
    $draw=$_REQUEST['draw'];

    /*Jumlah baris yang akan ditampilkan pada setiap page*/
    $length=$_REQUEST['length'];

    /*Offset yang akan digunakan untuk memberitahu database
    dari baris mana data yang harus ditampilkan untuk masing masing page
    */
    $start=$_REQUEST['start'];

    /*Keyword yang diketikan oleh user pada field pencarian*/
    $search=$_REQUEST['search']["value"];


    /*Menghitung total berita didalam database*/
    $this->db->select("*");
    $this->db->from("peserta_tanwir");
    $this->db->where("peserta_tanwir.wilayah",$wilayah);
    $total=$this->db->count_all_results();

    /*Mempersiapkan array tempat kita akan menampung semua data
    yang nantinya akan server kirimkan ke client*/
    $output=array();

    /*Token yang dikrimkan client, akan dikirim balik ke client*/
    $output['draw']=$draw;

    /*
    $output['recordsTotal'] adalah total data sebelum difilter
    $output['recordsFiltered'] adalah total data ketika difilter
    Biasanya kedua duanya bernilai sama, maka kita assignment 
    keduaduanya dengan nilai dari $total
    */
    $output['recordsTotal']=$output['recordsFiltered']=$total;

    /*disini nantinya akan memuat data yang akan kita tampilkan 
    pada table client*/
    $output['data']=array();


    /*Jika $search mengandung nilai, berarti user sedang telah 
    memasukan keyword didalam filed pencarian*/
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("no_ktna",$search);
    $this->db->or_like("pekerjaan",$search);
    $this->db->or_like("no_hp",$search);
    $this->db->or_like("pendidikan_terakhir",$search);
    $this->db->or_like("wilayah",$search);
    }


    /*Lanjutkan pencarian ke database*/
    $this->db->limit($length,$start);
    /*Urutkan dari alphabet paling terkahir*/
    // $this->db->order_by('nama','desc');
    $this->db->select("*");
    $this->db->from("peserta_tanwir");
    $this->db->where("peserta_tanwir.wilayah",$wilayah);
    $query=$this->db->get();


    /*Ketika dalam mode pencarian, berarti kita harus mengatur kembali nilai 
    dari 'recordsTotal' dan 'recordsFiltered' sesuai dengan jumlah baris
    yang mengandung keyword tertentu
    */
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("no_ktna",$search);
    $this->db->or_like("pekerjaan",$search);
    $this->db->or_like("no_hp",$search);
    $this->db->or_like("pendidikan_terakhir",$search);
    $this->db->or_like("wilayah",$search);

    $this->db->select("*");
    $this->db->from("peserta_tanwir");
    $this->db->where("peserta_tanwir.wilayah",$wilayah);
    $jum=$this->db->get();
    $output['recordsTotal']=$output['recordsFiltered']=$jum->num_rows();
    }

    $this->db->select("*");
    $this->db->from("peserta_tanwir");
    $this->db->where("peserta_tanwir.wilayah",$wilayah);
    $tot=$this->db->get(); 


    $nomor_urut=$start+1;
    $tanggal = getdate();
    foreach ($query->result_array() as $peserta_tanwir) {
        if($peserta_tanwir['foto'] == ""){
          $foto = "kosong.png";
        }else{
          $foto = $peserta_tanwir['foto'];
        }
        if($peserta_tanwir['verifikasi'] == "Belum Verifikasi"){
          $verifikasi = "<input type='radio' name='id_peserta' value='".$peserta_tanwir['id_peserta']."' required> Verifikasi awal";
        }elseif($peserta_tanwir['verifikasi'] == "Verifikasi Awal"){
          $verifikasi = "<button class='btn btn-success btn-xs'><i class='fa fa-check'></i></button> Verifikasi Awal";
        }else{
          $verifikasi = "<button class='btn btn-success btn-xs'><i class='fa fa-check'></i></button> Verifikasi Akhir";
        }
        $output['data'][]=array(
          $nomor_urut,
          "<img src='".base_url()."assets/dist/img/peserta/".$foto."' class='img-circle' style='height:20%;'>",
          $peserta_tanwir['nama'],
          $verifikasi);
        $nomor_urut++;
    }
    echo json_encode($output);
  }













  public function getDataAcaraPeserta(){
    /*Menagkap semua data yang dikirimkan oleh client*/

    /*Sebagai token yang yang dikrimkan oleh client, dan nantinya akan
    server kirimkan balik. Gunanya untuk memastikan bahwa user mengklik paging
    sesuai dengan urutan yang sebenarnya */
    $draw=$_REQUEST['draw'];

    /*Jumlah baris yang akan ditampilkan pada setiap page*/
    $length=$_REQUEST['length'];

    /*Offset yang akan digunakan untuk memberitahu database
    dari baris mana data yang harus ditampilkan untuk masing masing page
    */
    $start=$_REQUEST['start'];

    /*Keyword yang diketikan oleh user pada field pencarian*/
    $search=$_REQUEST['search']["value"];


    /*Menghitung total berita didalam database*/
    $this->db->select("*");
    $this->db->from("peserta_tanwir p");
    $this->db->join("acara_peserta ap","p.id_peserta=ap.id_peserta");
    $this->db->join("acara_tanwir a","a.id_acara=ap.id_acara");
    $total=$this->db->count_all_results();

    /*Mempersiapkan array tempat kita akan menampung semua data
    yang nantinya akan server kirimkan ke client*/
    $output=array();

    /*Token yang dikrimkan client, akan dikirim balik ke client*/
    $output['draw']=$draw;

    /*
    $output['recordsTotal'] adalah total data sebelum difilter
    $output['recordsFiltered'] adalah total data ketika difilter
    Biasanya kedua duanya bernilai sama, maka kita assignment 
    keduaduanya dengan nilai dari $total
    */
    $output['recordsTotal']=$output['recordsFiltered']=$total;

    /*disini nantinya akan memuat data yang akan kita tampilkan 
    pada table client*/
    $output['data']=array();


    /*Jika $search mengandung nilai, berarti user sedang telah 
    memasukan keyword didalam filed pencarian*/
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("no_ktna",$search);
    $this->db->or_like("pekerjaan",$search);
    $this->db->or_like("no_hp",$search);
    $this->db->or_like("pendidikan_terakhir",$search);
    $this->db->or_like("wilayah",$search);
    $this->db->or_like("nama_acara",$search);
    }


    /*Lanjutkan pencarian ke database*/
    $this->db->limit($length,$start);
    /*Urutkan dari alphabet paling terkahir*/
    // $this->db->order_by('nama','desc');
    $this->db->select("*");
    $this->db->from("peserta_tanwir p");
    $this->db->join("acara_peserta ap","p.id_peserta=ap.id_peserta");
    $this->db->join("acara_tanwir a","a.id_acara=ap.id_acara");
    $query=$this->db->get();


    /*Ketika dalam mode pencarian, berarti kita harus mengatur kembali nilai 
    dari 'recordsTotal' dan 'recordsFiltered' sesuai dengan jumlah baris
    yang mengandung keyword tertentu
    */
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("no_ktna",$search);
    $this->db->or_like("pekerjaan",$search);
    $this->db->or_like("no_hp",$search);
    $this->db->or_like("pendidikan_terakhir",$search);
    $this->db->or_like("wilayah",$search);
    $this->db->or_like("nama_acara",$search);

    $this->db->select("*");
    $this->db->from("peserta_tanwir p");
    $this->db->join("acara_peserta ap","p.id_peserta=ap.id_peserta");
    $this->db->join("acara_tanwir a","a.id_acara=ap.id_acara");
    $jum=$this->db->get();
    $output['recordsTotal']=$output['recordsFiltered']=$jum->num_rows();
    }

    $this->db->select("*");
    $this->db->from("peserta_tanwir p");
    $this->db->join("acara_peserta ap","p.id_peserta=ap.id_peserta");
    $this->db->join("acara_tanwir a","a.id_acara=ap.id_acara");
    $tot=$this->db->get(); 


    $nomor_urut=$start+1;
    $tanggal = getdate();
    foreach ($query->result_array() as $peserta_tanwir) {
        $output['data'][]=array(
          $nomor_urut,
          $peserta_tanwir['nama'],
          $peserta_tanwir['nama_acara']);
        $nomor_urut++;
    }
    echo json_encode($output);
  }












  public function getDataPeserta(){
    /*Menagkap semua data yang dikirimkan oleh client*/

    /*Sebagai token yang yang dikrimkan oleh client, dan nantinya akan
    server kirimkan balik. Gunanya untuk memastikan bahwa user mengklik paging
    sesuai dengan urutan yang sebenarnya */
    $draw=$_REQUEST['draw'];

    /*Jumlah baris yang akan ditampilkan pada setiap page*/
    $length=$_REQUEST['length'];

    /*Offset yang akan digunakan untuk memberitahu database
    dari baris mana data yang harus ditampilkan untuk masing masing page
    */
    $start=$_REQUEST['start'];

    /*Keyword yang diketikan oleh user pada field pencarian*/
    $search=$_REQUEST['search']["value"];


    /*Menghitung total berita didalam database*/
    $total=$this->db->count_all_results("peserta_tanwir");

    /*Mempersiapkan array tempat kita akan menampung semua data
    yang nantinya akan server kirimkan ke client*/
    $output=array();

    /*Token yang dikrimkan client, akan dikirim balik ke client*/
    $output['draw']=$draw;

    /*
    $output['recordsTotal'] adalah total data sebelum difilter
    $output['recordsFiltered'] adalah total data ketika difilter
    Biasanya kedua duanya bernilai sama, maka kita assignment 
    keduaduanya dengan nilai dari $total
    */
    $output['recordsTotal']=$output['recordsFiltered']=$total;

    /*disini nantinya akan memuat data yang akan kita tampilkan 
    pada table client*/
    $output['data']=array();


    /*Jika $search mengandung nilai, berarti user sedang telah 
    memasukan keyword didalam filed pencarian*/
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("no_ktna",$search);
    $this->db->or_like("pekerjaan",$search);
    $this->db->or_like("no_hp",$search);
    $this->db->or_like("pendidikan_terakhir",$search);
    $this->db->or_like("wilayah",$search);
    }


    /*Lanjutkan pencarian ke database*/
    $this->db->limit($length,$start);
    /*Urutkan dari alphabet paling terkahir*/
    // $this->db->order_by('nama','desc');
    $query=$this->db->get("peserta_tanwir");


    /*Ketika dalam mode pencarian, berarti kita harus mengatur kembali nilai 
    dari 'recordsTotal' dan 'recordsFiltered' sesuai dengan jumlah baris
    yang mengandung keyword tertentu
    */
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("no_ktna",$search);
    $this->db->or_like("pekerjaan",$search);
    $this->db->or_like("no_hp",$search);
    $this->db->or_like("pendidikan_terakhir",$search);
    $this->db->or_like("wilayah",$search);

    $jum=$this->db->get("peserta_tanwir");
    $output['recordsTotal']=$output['recordsFiltered']=$jum->num_rows();
    }

    $tot=$this->db->get("peserta_tanwir"); 


    $nomor_urut=$start+1;
    $tanggal = getdate();
    foreach ($query->result_array() as $peserta_tanwir) {
        $output['data'][]=array(
          $nomor_urut,
          $peserta_tanwir['nama'],
          $tanggal['year']-$peserta_tanwir['tanggal_lahir'],
          $peserta_tanwir['wilayah'],
          $peserta_tanwir['verifikasi'],
          "<button class='btn btn-xs btn-info detail-peserta' data-id='".$peserta_tanwir['id_peserta']."'><i class='fa fa-info'></i>&nbsp; Detail</button>
          <button class='btn btn-xs btn-warning edit-peserta' data-id='".$peserta_tanwir['id_peserta']."'><i class='fa fa-pencil'></i>&nbsp; Edit</button>
            <button class='btn btn-xs btn-danger hapus-peserta' data-id='".$peserta_tanwir['id_peserta']."'><i class='fa fa-trash'></i>&nbsp; Hapus</button>");
        $nomor_urut++;
    }
    echo json_encode($output);
  }

  public function modalEditPeserta(){
    foreach ($this->MData->getDataPesertaById($_POST['id'])->result() as $key) {
        $nama = $key->nama;
        $no_ktna = $key->no_ktna;
        $tanggal_lahir = $key->tanggal_lahir;
        $tempat_lahir = $key->tempat_lahir;
        $alamat = $key->alamat;
        $pekerjaan = $key->pekerjaan;
        $no_hp = $key->no_hp;
        $email = $key->email;
        $pendidikan_terakhir = $key->pendidikan_terakhir;
        $wilayah = $key->wilayah;
        $foto = $key->foto;
        $tahun_aktif = $key->tahun_aktif;
        $jumlah_anak_dibawa = $key->jumlah_anak_dibawa;
        $tanggal_datang = $key->tanggal_datang;
        $jam_datang = $key->jam_datang;
        $tanggal_pulang = $key->tanggal_pulang;
        $jam_pulang = $key->jam_pulang;
    }
    $organisasi = $this->MData->getOrganisasiByIdPeserta($_POST['id']);
    $hasilOrganisasi = "";
    foreach ($organisasi->result() as $value) {
      if($value->IPM_IRM == 1){
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='IPM / IRM' class='form-check-input' checked> IPM / IRM ";
      }else{
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='IPM / IRM' class='form-check-input'> IPM / IRM ";
      }
      if($value->IMM == 1){
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='IMM' lass='form-check-input' checked> IMM <br>";
      }else{
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='IMM' lass='form-check-input'> IMM <br>";
      }
      if($value->lainnya != ""){
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='Lainnya' class='form-check-input' checked> Lainnya";
        $hasilOrganisasi = $hasilOrganisasi."<textarea class='form-control' rows='2' name='organisasi[]' placeholder='Sebutkan'>".$value->lainnya."</textarea>";
      }else{
        $hasilOrganisasi = $hasilOrganisasi."<input type='checkbox' name='organisasi[]' value='Lainnya' class='form-check-input'> Lainnya";
        $hasilOrganisasi = $hasilOrganisasi."<textarea class='form-control' rows='2' name='organisasi[]' placeholder='Sebutkan'></textarea>";
      }
    }

    $informasi = $this->MData->getInformasiByIdPeserta($_POST['id']);

    $hasilInformasi = "";
    foreach ($informasi->result() as $value) {
      if($value->dalam_keadaan_sehat_bugar == 1){
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi1' value='Dalam keadaan sehat bugar' class='form-check-input' checked> Dalam keadaan sehat bugar <br>";
      }else{
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi1' value='Dalam keadaan sehat bugar' class='form-check-input'> Dalam keadaan sehat bugar <br>";
      }
      if($value->dalam_masa_pemulihan_pasca_sakit_kecelakaan == 1){
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi2' value='Dalam masa pemulihan pasca sakit / kecelakaan' class='form-check-input' checked> Dalam masa pemulihan pasca sakit / kecelakaan <br>";
      }else{
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi2' value='Dalam masa pemulihan pasca sakit / kecelakaan' class='form-check-input'> Dalam masa pemulihan pasca sakit / kecelakaan <br>";
      }
      if($value->membawa_pengasuh_untuk_anak == 1){
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi3' value='Membawa pengasuh untuk anak' class='form-check-input' checked> Membawa pengasuh untuk anak <br>";
      }else{
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi3' value='Membawa pengasuh untuk anak' class='form-check-input'> Membawa pengasuh untuk anak <br>";
      }
      if($value->sedang_hamil_atau_menyusui == 1){
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi4' value='Sedang hamil atau menyusui' class='form-check-input' checked> Sedang hamil atau menyusui";
      }else{
        $hasilInformasi = $hasilInformasi."<input type='checkbox' name='informasi[]' id='informasi4' value='Sedang hamil atau menyusui' class='form-check-input'> Sedang hamil atau menyusui";
      }
    }

    $acaraPeserta = $this->MData->getAcaraByIdPeserta($_POST['id']);
    $acara = $this->MData->getAcara();
    $hasilAcara = "";
    foreach ($acara->result() as $value) {
        $hasilAcara = $hasilAcara."<input type='checkbox' name='acara[]' value='".$value->id_acara."' class='form-check-input'";
        foreach ($acaraPeserta->result() as $key) {
          if($value->id_acara == $key->id_acara){
            $hasilAcara = $hasilAcara."checked";
          }
        }
        $hasilAcara = $hasilAcara.">".$value->nama_acara." <br>";
    }
    

    $pelatihan_kader = $this->MData->getPelatihanKaderByIdPeserta($_POST['id']);
    $hasilPelatihanKader = "<table style='width:50%;'><tr><td>";
    foreach ($pelatihan_kader->result() as $value) {
      if($value->taruna_melati_1 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 1' class='form-check-input' checked> Taruna Melati 1</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 1' class='form-check-input'> Taruna Melati 1</td><td>";
      }
      if($value->DAD == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAD' class='form-check-input' checked> DAD</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAD' class='form-check-input'> DAD</td><td>";
      }
      if($value->LT_1 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LT 1' class='form-check-input' checked> LT 1</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LT 1' class='form-check-input'> LT 1</td><td>";
      }
      if($value->LINA_1 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LINA I' class='form-check-input' checked> LINA I</td></tr><tr><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LINA I' class='form-check-input'> LINA I</td></tr><tr><td>";
      }
      if($value->taruna_melati_2 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 2' class='form-check-input' checked> Taruna Melati 2</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 2' class='form-check-input'> Taruna Melati 2</td><td>";
      }
      if($value->DAM == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAM' class='form-check-input' checked> DAM</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAM' class='form-check-input'> DAM</td><td>";
      }
      if($value->LT_2 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LT 2' class='form-check-input' checked> LT 2</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LT 2' class='form-check-input'> LT 2</td><td>";
      }
      if($value->LINA_2 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LINA II' class='form-check-input' checked> LINA II</td></tr><tr><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='LINA II' class='form-check-input'> LINA II</td></tr><tr><td>";
      }
      if($value->taruna_melati_3 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 3' class='form-check-input' checked> Taruna Melati 3</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='Taruna Melati 3' class='form-check-input'> Taruna Melati 3</td><td>";
      }
      if($value->DAP == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAP' class='form-check-input' checked> DAP</td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DAP' class='form-check-input'> DAP</td><td>";
      }
      if($value->DANA_1 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA I' class='form-check-input' checked> DANA I</td></tr><tr><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA I' class='form-check-input'> DANA I</td></tr><tr><td>";
      }
      if($value->tm_utama == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='TM Utama' class='form-check-input' checked> TM Utama</td><td></td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='TM Utama' class='form-check-input'> TM Utama</td><td></td><td>";
      }
      if($value->DANA_2 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA II' class='form-check-input' checked> DANA II</td></tr><tr><td></td><td></td><td>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA II' class='form-check-input'> DANA II</td></tr><tr><td></td><td></td><td>";
      }
      if($value->DANA_3 == 1){
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA III' class='form-check-input' checked> DANA III</td></tr></table>";
      }else{
        $hasilPelatihanKader = $hasilPelatihanKader."<input type='checkbox' name='pelatihan[]' value='DANA III' class='form-check-input'> DANA III</td></tr></table>";
      }
    }
    

    $hasilPekerjaan = "<select name='pekerjaan' class='form-control' required>
                <option value=''>-- Pilih pekerjaan --</option>";
    if($pekerjaan == "Pelajar"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Pelajar' selected>Pelajar</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Pelajar'>Pelajar</option>";
    }
    if($pekerjaan == "Mahasiswa"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Mahasiswa' selected>Mahasiswa</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Mahasiswa'>Mahasiswa</option>";
    }
    if($pekerjaan == "PNS"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='PNS' selected>PNS</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='PNS'>PNS</option>";
    }
    if($pekerjaan == "Swasta"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Swasta' selected>Swasta</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Swasta'>Swasta</option>";
    }
    if($pekerjaan == "Ibu rumah tangga"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Ibu rumah tangga' selected>Ibu rumah tangga</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Ibu rumah tangga'>Ibu rumah tangga</option>";
    }
    if($pekerjaan == "Dosen"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Dosen' selected>Dosen</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Dosen'>Dosen</option>";
    }
    if($pekerjaan == "Guru"){
      $hasilPekerjaan = $hasilPekerjaan."<option value='Guru' selected>Guru</option>";
    }else{
      $hasilPekerjaan = $hasilPekerjaan."<option value='Guru'>Guru</option>";
    }
    $hasilPekerjaan = $hasilPekerjaan."</select>";
                
    $hasilPendidikanTerakhir = "<select name='pendidikan_terakhir' class='form-control' required>
                <option value=''>-- Pendidikan terakhir --</option>";
    if($pendidikan_terakhir == "SMA/SMK"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='SMA/SMK' selected>SMA/SMK</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='SMA/SMK'>SMA/SMK</option>";
    }
    if($pendidikan_terakhir == "D1"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D1' selected>D1</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D1'>D1</option>";
    }
    if($pendidikan_terakhir == "D3"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D3' selected>D3</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D3'>D3</option>";
    }
    if($pendidikan_terakhir == "D4"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D4' selected>D4</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='D4'>D4</option>";
    }
    if($pendidikan_terakhir == "S1"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S1' selected>S1</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S1'>S1</option>";
    }
    if($pendidikan_terakhir == "S2"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S2' selected>S2</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S2'>S2</option>";
    }
    if($pendidikan_terakhir == "S3"){
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S3' selected>S3</option>";
    }else{
      $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."<option value='S3'>S3</option>";
    }
    $hasilPendidikanTerakhir = $hasilPendidikanTerakhir."</select>";


              
      
    echo "<div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
            <span aria-hidden='true'>&times;</span></button>
            <h4 class='modal-title'>Edit Data Peserta</h4>
        </div>
        <div class='modal-body'>
          <form action='".base_url()."Peserta/editPeserta' method='POST' enctype='multipart/form-data'>
          <input type='hidden' name='id_peserta' value='".$_POST['id']."'>
          <input type='hidden' name='foto' value='".$foto."'>
          <input type='hidden' name='no_ktnaAwal' value='".$no_ktna."'>
          <div class='form-group'>
            <label >No. KTNA</label>
            <p>
              <input type='text' value='".$no_ktna."' class='form-control' name='no_ktna' required placeholder='Nama'>
            </p>
          </div>
          <div class='form-group'>
            <label >Nama</label>
            <p>
              <input type='text' value='".$nama."' class='form-control' name='nama' required placeholder='Nama'>
            </p>
          </div>
          <div class='form-group'>
            <label >Tempat Lahir</label>
            <p>
              <input type='text' value='".$tempat_lahir."' class='form-control' name='tempat_lahir' required placeholder='Username'>
            </p>
          </div>
          <div class='form-group'>
            <label >Tanggal Lahir</label>
            <p>
              <input type='date' value='".$tanggal_lahir."' class='form-control' name='tanggal_lahir' required placeholder='Username'>
              <span class='help-block'>Format tanggal 20/12/2017</span>
            </p>
          </div>
          <div class='form-group'>
            <label>Alamat</label>
            <p>
              <textarea name='alamat' class='form-control' rows='2'>".$alamat."</textarea>
            </p>
          </div>
          <div class='form-group'>
            <label>Pekerjaan</label>
            <p>
              ".$hasilPekerjaan."
            </p>
          </div>
          <div class='form-group'>
            <label >No HP</label>
            <p>
              <input type='text' value='".$no_hp."' class='form-control' name='no_hp' required placeholder='Nomor telepon'>
            </p>
          </div>
          <div class='form-group'>
            <label>Email</label>
            <p>
              <input type='text' value='".$email."' class='form-control' name='email' required placeholder='Nomor telepon'>
            </p>
          </div>
          <div class='form-group'>
            <label>Pendidikan Terakhir</label>
            <p>
              ".$hasilPendidikanTerakhir."
            </p>
          </div>
          <div class='form-group'>
            <label >Utusan</label>
            <p>
              <input type='text' value='".$wilayah."' class='form-control' name='wilayah' required placeholder='Utusan'>
            </p>
          </div>
          <div class='form-group'>
            <label >Foto</label>
            <p>
              <input type='file' name='userfile' class='form-control' required>
              <span class='help-block'>Max dimension 215 x 215. Tipe file jpg | png</span>
            </p>
          </div>
          <div class='form-group'>
            <label>Organisasi yang diikuti sebelum NA</label>
            <p>
              ".$hasilOrganisasi."
            </p>
          </div>
          <div class='form-group'>
            <label>Tahun Aktif di NA</label>
            <p>
              <input type='number' value='".$tahun_aktif."' class='form-control' name='tahun_aktif' required placeholder='Tahun Aktif'>
            </p>
          </div>
          <div class='form-group'>
            <label>Pelatihan Perkaderan yang Pernah Diikuti</label>
            <p>
              ".$hasilPelatihanKader."
            </p>
          </div>
          <div class='form-group'>
            <label>Acara yang Diikuti dalam TANWIR</label>
            <p>
              ".$hasilAcara."
            </p>
          </div>
          <div class='form-group'>
            <label>Tanggal Datang</label>
            <p>
              <input type='date' value='".$tanggal_datang."' class='form-control' name='tanggal_datang' required>
              <span class='help-block'>Format tanggal 20/12/2017</span>
            </p>
          </div>
          <div class='form-group'>
            <label>Jam Datang</label>
            <p>
              <input type='time' value='".$jam_datang."' class='form-control' name='jam_datang' required>
            </p>
          </div>
          <div class='form-group'>
            <label>Tanggal Pulang</label>
            <p>
              <input type='date' value='".$tanggal_pulang."' class='form-control' name='tanggal_pulang' required>
              <span class='help-block'>Format tanggal 20/12/2017</span>
            </p>
          </div>
          <div class='form-group'>
            <label>Jam Pulang</label>
            <p>
              <input type='time' value='".$jam_pulang."' class='form-control' name='jam_pulang' required>
            </p>
          </div>
          <div class='form-group'>
            <label>Jumlah Anak yang Dibawa</label>
            <p>
              <input type='number' value='".$jumlah_anak_dibawa."' class='form-control' name='jumlah_anak_dibawa' required>
            </p>
          </div>
          <div class='form-group'>
            <label>Infromasi lain (Wajib diisi, bisa dipilih lebih dari satu)</label>
            <span class='help-block'>(Boleh lebih dari 1)</span>
            <p>
              ".$hasilInformasi."
            </p>
          </div>
          <button type='submit' class='btn btn-success'>Submit</button>
          </form>
        </div>

        <script>//re password validation
        var password = document.getElementById('password".$_POST['id']."'), confirm_password = document.getElementById('confirm_password".$_POST['id']."');

        function validatePassword(){
          if(password.value != confirm_password.value) {
            confirm_password".$_POST['id'].".setCustomValidity('Password does not match');
          } else {
            confirm_password".$_POST['id'].".setCustomValidity('');
          }
        }

        password".$_POST['id'].".onchange = validatePassword;
        confirm_password".$_POST['id'].".onkeyup = validatePassword;</script>
        ";
  }

  public function gambarBarcode($kode){
    //load library
    $this->load->library('zend');
    //load in folder Zend
    $this->zend->load('Zend/Barcode');
    $height = isset($_GET['height']) ? mysql_real_escape_string($_GET['height']) : '60';  $width = isset($_GET['width']) ? mysql_real_escape_string($_GET['width']) : '1'; //1,2,3,dst

      $barcodeOPT = array(
        'text' => $kode,
      'barHeight'=> $height,
      'factor'=>$width,
    );

    $renderOPT = array();

    $render = Zend_Barcode::factory('Code39', 'image', $barcodeOPT, $renderOPT)->render();
  }

  public function modalDetailPeserta(){
    foreach ($this->MData->getDataPesertaById($_POST['id'])->result() as $value) {
      if($value->foto == NULL){
        $foto = "kosong.png";
      }else{
        $foto = $value->foto;
      }
      $nama = $value->nama;
      $wilayah = $value->wilayah;
      $barcode = $value->barcode;     
    }
    $acara = "";
    $i = 1;
    foreach ($this->MData->getAcaraByIdPeserta($_POST['id'])->result() as $key) {
      $acara = $acara.$i.". ".$key->nama_acara."<br>";
      $i++;
    }
    $tombolCetakIdCard = "<a href='".base_url()."Peserta/CetakIdCard/".$_POST['id']."' target='_blank'><button class='btn btn btn-success'><i class='fa fa-print'></i>&nbsp; Cetak Id Card</button></a>";
    echo "<div class='modal-header'>
          <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
            <span aria-hidden='true'>&times;</span></button>
          <h4 class='modal-title'>Data Peserta TANWIR</h4>
        </div>
        <div class='modal-body'>
          <div class='row'>
              <div class='col-md-3'>
                <div href='#' class='thumbnail' >
                  <img src='".base_url()."assets/dist/img/peserta/".$foto."' alt='Nama File'>
                </div> 
                <div href='#' class='thumbnail' > 
                  <img src='".base_url()."Data/gambarBarcode/".$barcode."' >
                </div>
              </div>
              <div class='col-md-9'>
                <table>
                  <tr>
                    <td><b>Nama</b></td>
                    <td style='width:10px;'></td>
                    <td>".$nama."</td>
                  </tr>
                  <tr>
                    <td>.</td>
                    <td style='width:10px;'></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Utusan</b></td>
                    <td style='width:10px;'></td>
                    <td>".$wilayah."</td>
                  </tr>
                  <tr>
                    <td>.</td>
                    <td style='width:10px;'></td>
                    <td></td>
                  </tr>
                  <tr style='padding-top:100px;'>
                    <td><b>Acara yang diikuti</b></td>
                    <td style='width:10px;'></td>
                    <td rowspan='2'>".$acara."</td>
                  </tr>
                </table>
              </div>
          </div>
        </div>
        <div class='modal-footer'>
          ".$tombolCetakIdCard."
          <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
        </div>";
  }
  public function modalHapusPeserta(){
    foreach ($this->MData->getDataPesertaById($_POST['id'])->result() as $key) {
        $nama = $key->nama;
        $foto = $key->foto;
    }

    echo "<div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal'><span aria-hidden='true'>&times;</span><span class='sr-only'>Close</span></button>
            <h4 class='modal-title' id='myModalLabel'>Hapus data peserta</h4>
          </div>
          <div class='modal-body'>
              Hapus data ".$nama." ?
           </div>
           <div class='modal-footer'>
              <button type='button' class='btn btn-default' data-dismiss='modal'>Tidak</button>
              <a href='".base_url()."Peserta/hapusPeserta/".$_POST['id']."/".$foto."'><button type='button' id='confirmHapus' class='simpan btn btn-primary'>Ya</button></a>
           </div>";
  }

























  public function getDataPengguna(){
    /*Menagkap semua data yang dikirimkan oleh client*/

    /*Sebagai token yang yang dikrimkan oleh client, dan nantinya akan
    server kirimkan balik. Gunanya untuk memastikan bahwa user mengklik paging
    sesuai dengan urutan yang sebenarnya */
    $draw=$_REQUEST['draw'];

    /*Jumlah baris yang akan ditampilkan pada setiap page*/
    $length=$_REQUEST['length'];

    /*Offset yang akan digunakan untuk memberitahu database
    dari baris mana data yang harus ditampilkan untuk masing masing page
    */
    $start=$_REQUEST['start'];

    /*Keyword yang diketikan oleh user pada field pencarian*/
    $search=$_REQUEST['search']["value"];


    /*Menghitung total berita didalam database*/
    $total=$this->db->count_all_results("pengguna_tanwir");

    /*Mempersiapkan array tempat kita akan menampung semua data
    yang nantinya akan server kirimkan ke client*/
    $output=array();

    /*Token yang dikrimkan client, akan dikirim balik ke client*/
    $output['draw']=$draw;

    /*
    $output['recordsTotal'] adalah total data sebelum difilter
    $output['recordsFiltered'] adalah total data ketika difilter
    Biasanya kedua duanya bernilai sama, maka kita assignment 
    keduaduanya dengan nilai dari $total
    */
    $output['recordsTotal']=$output['recordsFiltered']=$total;

    /*disini nantinya akan memuat data yang akan kita tampilkan 
    pada table client*/
    $output['data']=array();


    /*Jika $search mengandung nilai, berarti user sedang telah 
    memasukan keyword didalam filed pencarian*/
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("username",$search);
    $this->db->or_like("no_hp",$search);
    }


    /*Lanjutkan pencarian ke database*/
    $this->db->limit($length,$start);
    /*Urutkan dari alphabet paling terkahir*/
    // $this->db->order_by('nama','desc');
    $query=$this->db->get("pengguna_tanwir");


    /*Ketika dalam mode pencarian, berarti kita harus mengatur kembali nilai 
    dari 'recordsTotal' dan 'recordsFiltered' sesuai dengan jumlah baris
    yang mengandung keyword tertentu
    */
    if($search!=""){
    $this->db->like("nama",$search);
    $this->db->or_like("username",$search);
    $this->db->or_like("no_hp",$search);

    $jum=$this->db->get("pengguna_tanwir");
    $output['recordsTotal']=$output['recordsFiltered']=$jum->num_rows();
    }

    $tot=$this->db->get("pengguna_tanwir"); 


    $nomor_urut=$start+1;
    foreach ($query->result_array() as $pengguna) {
        $output['data'][]=array(
          $nomor_urut,
          $pengguna['nama'],
          $pengguna['username'],
          $pengguna['no_hp'],
          "<button class='btn btn-xs btn-info detail-pengguna' data-id='".$pengguna['id_pengguna']."'><i class='fa fa-info'></i>&nbsp; Detail</button>
          <button class='btn btn-xs btn-warning edit-pengguna' data-id='".$pengguna['id_pengguna']."'><i class='fa fa-pencil'></i>&nbsp; Edit</button>
            <button class='btn btn-xs btn-danger hapus-pengguna' data-id='".$pengguna['id_pengguna']."'><i class='fa fa-trash'></i>&nbsp; Hapus</button>");
        $nomor_urut++;
    }
    echo json_encode($output);
  }

  public function modalDetailPengguna(){
    foreach ($this->MData->getDataPenggunaById($_POST['id'])->result() as $key) {
        $nama = $key->nama;
        $username = $key->username;
        $no_hp = $key->no_hp;
        $foto = $key->foto;
    }

    echo "<div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
            <span aria-hidden='true'>&times;</span></button>
            <h4 class='modal-title'>Detail Pengguna</h4>
        </div>
        <div class='modal-body'>
          <div class='col-md-12'>
            <a href='#' class='thumbnail'>
              <img src='".base_url()."assets/dist/img/pengguna/".$foto."'>
            </a>
          </div>
          <table>
            <tr>
              <td>
                <div class='form-group'>
                  <label >Nama</label>
                  <p>
                    ".$nama."
                  </p>
                </div>
              </td>
              <td rowspan='2' style='width:25%;'></td>
              <td>
                <div class='form-group'>
                  <label >Username</label>
                  <p>
                    ".$username."
                  </p>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class='form-group'>
                  <label >No telepon</label>
                  <p>
                    ".$no_hp."
                  </p>
                </div>
              </td>
            </tr>
          </table>       
          ";
  }

  public function modalEditPengguna(){
    foreach ($this->MData->getDataPenggunaById($_POST['id'])->result() as $key) {
        $nama = $key->nama;
        $username = $key->username;
        $no_hp = $key->no_hp;
        $foto = $key->foto;
    }

    echo "<div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
            <span aria-hidden='true'>&times;</span></button>
            <h4 class='modal-title'>Edit Data Pengguna</h4>
        </div>
        <div class='modal-body'>
          <div class='col-md-12'>
            <a href='#' class='thumbnail'>
              <img src='".base_url()."assets/dist/img/pengguna/".$foto."'>
            </a>
          </div>
          <form action='".base_url()."Pengguna/editPengguna' method='POST' enctype='multipart/form-data'>
          <input type='hidden' name='id_pengguna' value='".$_POST['id']."'>
          <input type='hidden' name='foto' value='".$foto."'>
          <input type='hidden' name='usernameAwal' value='".$username."'>
          <div class='form-group'>
            <label >Nama</label>
            <p>
              <input type='text' value='".$nama."' class='form-control' name='nama' required placeholder='Nama'>
            </p>
          </div>
          <div class='form-group'>
            <label >Username</label>
            <p>
              <input type='text' value='".$username."' class='form-control' name='username' required placeholder='Username'>
            </p>
          </div>
          <div class='form-group'>
            <label >Password</label>
            <p>
              <input type='password' value='' class='form-control' name='password' required placeholder='Password' id='password".$_POST['id']."'><br>
              <input type='password' value='' class='form-control' required placeholder='Repassword' id='confirm_password".$_POST['id']."'>
            </p>
          </div>
          <div class='form-group'>
            <label >No telepon</label>
            <p>
              <input type='text' value='".$no_hp."' class='form-control' name='no_hp' required placeholder='Nomor telepon'>
            </p>
          </div>
          <div class='form-group'>
            <label >Foto</label>
            <p>
              <input type='file' name='userfile' class='form-control' required>
              <span class='help-block'>Max dimension 215 x 215. Tipe file jpg | png</span>
            </p>
          </div>
          <button type='submit' class='btn btn-success'>Submit</button>
          </form>
        </div>

        <script>//re password validation
        var password = document.getElementById('password".$_POST['id']."'), confirm_password = document.getElementById('confirm_password".$_POST['id']."');

        function validatePassword(){
          if(password.value != confirm_password.value) {
            confirm_password".$_POST['id'].".setCustomValidity('Password does not match');
          } else {
            confirm_password".$_POST['id'].".setCustomValidity('');
          }
        }

        password".$_POST['id'].".onchange = validatePassword;
        confirm_password".$_POST['id'].".onkeyup = validatePassword;</script>
        ";
  }
  
  public function modalHapusPengguna(){
    foreach ($this->MData->getDataPenggunaById($_POST['id'])->result() as $key) {
        $nama = $key->nama;
        $foto = $key->foto;
    }

    echo "<div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal'><span aria-hidden='true'>&times;</span><span class='sr-only'>Close</span></button>
            <h4 class='modal-title' id='myModalLabel'>Hapus data pengguna</h4>
          </div>
          <div class='modal-body'>
              Hapus data ".$nama." ?
           </div>
           <div class='modal-footer'>
              <button type='button' class='btn btn-default' data-dismiss='modal'>Tidak</button>
              <a href='".base_url()."Pengguna/hapusPengguna/".$_POST['id']."/".$foto."'><button type='button' id='confirmHapus' class='simpan btn btn-primary'>Ya</button></a>
           </div>";
  } 
}