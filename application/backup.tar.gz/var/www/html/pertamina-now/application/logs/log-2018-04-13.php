<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-04-13 14:51:18 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 14:51:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-13 14:51:18 --> Severity: Parsing Error --> syntax error, unexpected 'a0fda8' (T_STRING) C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 191
DEBUG - 2018-04-13 14:54:55 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 14:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-13 14:54:56 --> Severity: Parsing Error --> syntax error, unexpected 'a0fda8' (T_STRING) C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 192
DEBUG - 2018-04-13 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 14:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-13 14:55:22 --> Severity: Parsing Error --> syntax error, unexpected 'a0fda8' (T_STRING) C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 220
DEBUG - 2018-04-13 14:57:19 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 14:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-13 14:57:19 --> Severity: Parsing Error --> syntax error, unexpected 'a0fda8' (T_STRING) C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 221
DEBUG - 2018-04-13 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:01:09 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:01:09 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:01:09 --> Nexmo class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 15:01:09 --> Total execution time: 1.8127
DEBUG - 2018-04-13 15:01:16 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:01:16 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:01:16 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:01:16 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:01:16 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `jenis_kelamin`, `tanggal_lahir`, `tempat_lahir`, `email`, `no_tlp`, `username`, `password`, `rule`) VALUES (NULL, NULL, NULL, NULL, NULL, '+6285642943447', NULL, NULL, 0)
DEBUG - 2018-04-13 15:01:17 --> Total execution time: 0.3927
DEBUG - 2018-04-13 15:01:58 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:01:59 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:01:59 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:01:59 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:02:00 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (17, 'MTcqKkx6S2xEWGRxckNoWm9uVUZiQnl4NDhkY0pqa0pxWlNKUHVsamNGRjNmUmwzYVZrVEhjNkczeEIxWWdsWURkZjlNTE9FREswNFV1aXVQUkR2NWJ2ZFdpU2Q0emRBSg==', 0, 0, 0, NULL, '2018-04-13 03:02:00', '2018-04-13 06:02:00')
ERROR - 2018-04-13 15:02:04 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 217
ERROR - 2018-04-13 15:02:04 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:02:04 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 223
ERROR - 2018-04-13 15:02:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 15:02:05 --> Total execution time: 6.9663
DEBUG - 2018-04-13 15:53:16 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:53:17 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:53:17 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:53:18 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:53:18 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (18, 'MTgqWGNkc3N1N2ltOU91bXdON0dyMU0zZ1lBSFBCN2pzb3M4MmpkU1NPdExQU1F1ZlhvalgzSlVrQlh4YkJFVFN1VmNlZ2xhQ24yMlNOenZsMDJPUlczRUw3SGdWc3ps', 0, 0, 0, NULL, '2018-04-13 03:53:18', '2018-04-13 06:53:18')
ERROR - 2018-04-13 15:53:19 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:53:19 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:53:19 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 15:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 15:53:19 --> Total execution time: 3.7061
DEBUG - 2018-04-13 15:54:54 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:54:54 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:54:54 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:54:54 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:54:54 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (19, 'MTkqRXRMOE82UmxLUFljakJGb09VNGI3SUxnQXVQUTJjUkZPa1lXTU9Lb2c4aGU2aDlhRkh0cUxtUEtNS2pqd1B4U2wzekQ2bzBqOGtYOGhQME5TbWZ5TVRoNmxTYkZu', 0, 0, 0, NULL, '2018-04-13 03:54:54', '2018-04-13 06:54:54')
ERROR - 2018-04-13 15:54:55 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:54:55 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:54:55 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 15:54:55 --> Total execution time: 1.4896
DEBUG - 2018-04-13 15:55:07 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:55:07 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:55:07 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:55:07 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:55:07 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (20, 'MjAqanpYZ0V3Y09SRTZvcDFVUGdlanRVb3liaDZraFRyU0NHWlV4N1JEVGJFTTFscnpLelFJc2pWcVh5aXJCTTNZZVZNSmN0QVdsbzJrMWFmNjNLT1lOQlBiNUlTcWh3', 0, 0, 0, NULL, '2018-04-13 03:55:07', '2018-04-13 06:55:07')
ERROR - 2018-04-13 15:55:08 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:55:08 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:55:08 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 15:55:08 --> Total execution time: 1.3299
DEBUG - 2018-04-13 15:56:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:56:20 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:56:20 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:56:20 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:56:21 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 241
ERROR - 2018-04-13 15:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 242
ERROR - 2018-04-13 15:56:21 --> Severity: Notice --> Undefined index: x-api-key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 327
ERROR - 2018-04-13 15:56:21 --> Severity: Notice --> Undefined variable: expired C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 334
DEBUG - 2018-04-13 15:56:21 --> Total execution time: 1.0902
DEBUG - 2018-04-13 15:56:53 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:56:53 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:56:53 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:56:53 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:56:53 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (21, 'MjEqM1dkMlhyZUhGOGJ1TktvUnJ2Sk5hN3dMNk5DSlBobGFxTUExdTBFTjhib3JXMjlxWk1NSlU4Q05LaXZEOTFORmF2alRwc3FNWThZaHJkaFNWV2N4MDE1SU1GTW9R', 0, 0, 0, NULL, '2018-04-13 03:56:53', '2018-04-13 06:56:53')
ERROR - 2018-04-13 15:56:54 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:56:54 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 223
ERROR - 2018-04-13 15:56:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 15:56:54 --> Total execution time: 1.5023
DEBUG - 2018-04-13 15:57:30 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:57:30 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:57:30 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:57:30 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:57:31 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (22, 'MjIqQ0IzaDVxREhOQUNiV1Zaa2dNY2VZMGR1TVd2YlZxM1U2TmpNeVZmbVo3bE1DZnpBYkVvVlNiTGxxOWFYM3J6bXRtckVVTUtwNDJYSmJYMmVZVXNZRUpjeldLSDcy', 0, 0, 0, NULL, '2018-04-13 03:57:31', '2018-04-13 06:57:31')
ERROR - 2018-04-13 15:57:31 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:57:31 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:57:31 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 15:57:31 --> Total execution time: 1.1575
DEBUG - 2018-04-13 15:57:39 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:57:39 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:57:39 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:57:39 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:57:39 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (23, 'MjMqUFliSGlyVDcxNlAxanE0QzJuZUV4cHBqRXVia0o3RFZCZm9PQ2t3ZERsQ1FZTU5XdkFDY3hkZFFYRjlBNHB4RktvWE5qNXZiQ3RNeTAwUzdrRm9DVlVvZkRKdkpO', 0, 0, 0, NULL, '2018-04-13 03:57:39', '2018-04-13 06:57:39')
ERROR - 2018-04-13 15:57:40 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:57:40 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:57:40 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 15:57:40 --> Total execution time: 1.1172
DEBUG - 2018-04-13 15:57:50 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:57:50 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:57:50 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:57:50 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:57:50 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (24, 'MjQqek9pZ3BVRW5JUzFZc2s4cTZsYnhDd1VGdVh3R0VlS1RCdE45amVuT2RDS0lrZkFjNWI3N3MyNU5WVEc2c2xEbXd1YXE1VlpEQktrUDR4VW1Wb1Y0YVY3amZjSVU4', 0, 0, 0, NULL, '2018-04-13 03:57:50', '2018-04-13 06:57:50')
ERROR - 2018-04-13 15:57:51 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:57:51 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:57:51 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 15:57:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 15:57:51 --> Total execution time: 1.1916
DEBUG - 2018-04-13 15:58:00 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:58:00 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:58:00 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:58:00 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:58:00 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (25, 'MjUqUG9kalRwNEowdFBSZk5qR2M2VEVaQ3BLYjNiclNDNEhHMnFZRng1ZnNQb1o2OWJhZmJPZ1diNmRPUXJ2V29DN1V5MXZQeHRFaDRrMG1tcHhGODVKaUNieVB2NHNu', 0, 0, 0, NULL, '2018-04-13 03:58:00', '2018-04-13 06:58:00')
ERROR - 2018-04-13 15:58:01 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:58:01 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:58:01 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 15:58:01 --> Total execution time: 1.3859
DEBUG - 2018-04-13 15:59:16 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:59:16 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:59:16 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:59:16 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:59:16 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (26, 'MjYqM3lxdldaVmxwZlZ0YkRTWXMxTXNZSzUwVkVMZDM0aGJBUUJ1Y2xkZmFvNDJha0RZcTFUQ0ZNajU3dFFZdHJZbVp3RVFsNG53TVU1WjFvZ2xnblRhZmNweWJHTjZN', 0, 0, 0, NULL, '2018-04-13 03:59:16', '2018-04-13 06:59:16')
ERROR - 2018-04-13 15:59:18 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:59:18 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:59:18 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 15:59:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 15:59:18 --> Total execution time: 1.9591
DEBUG - 2018-04-13 15:59:30 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:59:30 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:59:30 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:59:30 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:59:30 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (27, 'MjcqY3hVZ3pBem1hcGJoTlpqS1FNNVo3SzVIWW9vN2dEQ1drWlFxMG9HZkRrY0U0TDFtRWFjemV1bjE4ZUJWZGx2WlBpOXNONGExdDdCVUlwNVFRcEgySTcyZUZYY0J5', 0, 0, 0, NULL, '2018-04-13 03:59:30', '2018-04-13 06:59:30')
ERROR - 2018-04-13 15:59:31 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:59:31 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:59:31 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 15:59:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 15:59:32 --> Total execution time: 1.7368
DEBUG - 2018-04-13 15:59:40 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:59:40 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:59:40 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:59:40 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:59:40 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (28, 'MjgqV0xVSHZRbVlDMEVITW4ySlZ4Y3B5em96QjVpQXlhYWdvb0lYelQ4dzNmYWlqeDI4a21ybHlPQk9ZdmZSMnZCbEpwbkF2a05zbVF5Z0ozVVRCeXhGcnJIcWRpNXdv', 0, 0, 0, NULL, '2018-04-13 03:59:40', '2018-04-13 06:59:40')
ERROR - 2018-04-13 15:59:41 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 15:59:41 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:59:41 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 15:59:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 15:59:41 --> Total execution time: 1.7212
DEBUG - 2018-04-13 15:59:52 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 15:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 15:59:52 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 15:59:52 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 15:59:52 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 15:59:53 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (29, 'MjkqZFZOV05WQWs4a0t4UFBDMVhFMks4d21jcUZwa3NNeUNpNkMxeWxZMWpKcUFiWGxiZWh5TDVvcVBOdk1qMG1ZSUxhUFpIRUlCUzB0d1VZcmRUTXNGcDdSa3lld2JV', 0, 0, 0, NULL, '2018-04-13 03:59:53', '2018-04-13 06:59:53')
ERROR - 2018-04-13 15:59:54 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 217
ERROR - 2018-04-13 15:59:54 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 15:59:54 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 223
ERROR - 2018-04-13 15:59:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 15:59:54 --> Total execution time: 1.3523
DEBUG - 2018-04-13 16:00:27 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:00:27 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:00:27 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:00:27 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:00:27 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (30, 'MzAqT0tHQjZwT2NPUTJPYVRqMVJVOFU5SXI2SkdJRk9DVmQ4VXhPVW53NVJsbTdjSDB1REtWam9tNWFkUllhaDd4U2xyZ3BCSDdsTWV5TjZTeWxoWUE1d25CQ3pyNjJE', 0, 0, 0, NULL, '2018-04-13 04:00:27', '2018-04-13 07:00:27')
ERROR - 2018-04-13 16:00:28 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 217
ERROR - 2018-04-13 16:00:28 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:00:28 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 223
ERROR - 2018-04-13 16:00:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 16:00:28 --> Total execution time: 1.2775
DEBUG - 2018-04-13 16:00:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:00:32 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:00:32 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:00:32 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:00:32 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (31, 'MzEqWTJWcW1SbmFwelp6dUNSU3FZQU16N2Z3TTByTm42aFFkb2tuRGxJQnVVWmY2eml4bGhiYnh4TG94aEVVR1pUV1BEN2NpSHFVVzduTjdvNjRFc2FyVFBGOUdxZFRu', 0, 0, 0, NULL, '2018-04-13 04:00:32', '2018-04-13 07:00:32')
ERROR - 2018-04-13 16:00:33 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 217
ERROR - 2018-04-13 16:00:33 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:00:33 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 223
ERROR - 2018-04-13 16:00:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 16:00:33 --> Total execution time: 1.1849
DEBUG - 2018-04-13 16:00:37 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:00:37 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:00:37 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:00:37 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:00:37 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (32, 'MzIqS1RVT0xpVWtWdjZNYzlkdTVodGt3d0FDWldMY3JhS3JuZ0tiS1B0SjFZYVlhaHZmRVFLbnJmQkkxQmc2bHV1VFQwdFVDS1Z3Wk82eTBOR241TFVOZmx1YldDRG03', 0, 0, 0, NULL, '2018-04-13 04:00:37', '2018-04-13 07:00:37')
ERROR - 2018-04-13 16:00:38 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 217
ERROR - 2018-04-13 16:00:38 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:00:38 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 223
ERROR - 2018-04-13 16:00:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 16:00:38 --> Total execution time: 1.0419
DEBUG - 2018-04-13 16:01:02 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:01:02 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:01:02 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:01:02 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:01:02 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (33, 'MzMqYjZIZzgzMW0yZ0dRMVV3SUdKU3A1V0JWUGYxSTFUMExnelR3Q3d2WUlzZHpDQVFpV0VLQkxRTHVHVGZvTjEyaUlXc0V1U25zS3g3YUE5eUt6cjBHT0NrVVVwUVZY', 0, 0, 0, NULL, '2018-04-13 04:01:02', '2018-04-13 07:01:02')
ERROR - 2018-04-13 16:01:03 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:01:03 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:01:03 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 16:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 16:01:03 --> Total execution time: 1.1791
DEBUG - 2018-04-13 16:01:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:01:08 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:01:08 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:01:08 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:01:08 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (34, 'MzQqMXFHeGFvRko1Q1BhdXBFVkFENUE3RENmaGZkd05PbHRUY1hKaEl5bWJlNFhqNFpEVTVpWUZEcjNPeG92M2FDbkRrNmlncGltOWRiODE2ZEo1Vm5KNTE4ZmRkclJj', 0, 0, 0, NULL, '2018-04-13 04:01:08', '2018-04-13 07:01:08')
ERROR - 2018-04-13 16:01:09 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:01:09 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:01:09 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 16:01:09 --> Total execution time: 1.2289
DEBUG - 2018-04-13 16:03:47 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:03:47 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:03:47 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:03:47 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:03:47 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (35, 'MzUqVE5FZ1I4Zjd0V0paemJGQnZrYjk4bFJuTEhOdWduQWRaUGpMSzF6UlVydElqMkEzaWkxNUlibnlUOUpFSGJHNnNLazgxTmhzSlBBaXFNU25zOWZURlRnQW90Mkd1', 0, 0, 0, NULL, '2018-04-13 04:03:47', '2018-04-13 07:03:47')
ERROR - 2018-04-13 16:03:48 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:03:48 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:03:48 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 16:03:48 --> Total execution time: 1.2709
DEBUG - 2018-04-13 16:03:56 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:03:56 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:03:56 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:03:56 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:03:56 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (36, 'MzYqUmFSaXdKbkZybFdVNTVMVW95elpTUEFadHd3aEZJQUZwMXZ3Ynd2R1lOaXRkWDdNVEFFVHROOUhWOWp3Sk1tZFFmMTdKRnY0bUN4cWRjazBnMEJiWDhBTWdhWjlH', 0, 0, 0, NULL, '2018-04-13 04:03:56', '2018-04-13 07:03:56')
ERROR - 2018-04-13 16:03:57 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:03:57 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:03:57 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 16:03:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 16:03:57 --> Total execution time: 1.0139
DEBUG - 2018-04-13 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:04:07 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:04:07 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:04:07 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:04:07 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (37, 'MzcqZDE5OVJwNThjblFET0VKNk9xQ3ZOclFpUVRmdHl3YXUxeXJrUEdycTU4Wk1vRHFST29CQ1g4U3dXNTR6ald4YmNYN25iT2FBbkt2T2x1dXViZVlCdkloRG85aHdz', 0, 0, 0, NULL, '2018-04-13 04:04:07', '2018-04-13 07:04:07')
ERROR - 2018-04-13 16:04:08 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:04:08 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:04:08 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 16:04:08 --> Total execution time: 1.2950
DEBUG - 2018-04-13 16:04:18 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:04:18 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:04:18 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:04:18 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:04:18 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (38, 'MzgqZmlMTGVhalZQZ0QxZm9IRmRWWlZYSXRxYTRCZTVSbVhwcWNIb0E2MUlKeDNERnRtUEtuM3hQZEl1ZXNzVE80UXNWdzBxb012dXprclNqN3FqV0R4MGpQbkhMYjJB', 0, 0, 0, NULL, '2018-04-13 04:04:18', '2018-04-13 07:04:18')
ERROR - 2018-04-13 16:04:19 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:04:19 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:04:19 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 16:04:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 16:04:19 --> Total execution time: 1.4143
DEBUG - 2018-04-13 16:04:43 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:04:43 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:04:43 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:04:43 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:04:43 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (39, 'MzkqOUU2bk5JR2t6bG03TlplMGtFU0Z2THBtYWtxTUZNMDhRN0tiM01LNjdMQURveG4wSTJIVXJNRnpwR1FKWGdselZyS1FHSmFMMjRjMW1XVVN1alUwTEVoRjFWRHlD', 0, 0, 0, NULL, '2018-04-13 04:04:43', '2018-04-13 07:04:43')
ERROR - 2018-04-13 16:04:44 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:04:44 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:04:44 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 16:04:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 16:04:44 --> Total execution time: 1.2429
DEBUG - 2018-04-13 16:04:47 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:04:47 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:04:47 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:04:47 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:04:48 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (40, 'NDAqQjNUb0U4b0d5WWlsZmFpSWVPQ0R0dFpzcGhEMDJOZkVQOTRkS1VPM2ZhSDFqd3FxbzVmOXVxUncyRXRuMmxQM1ZCOHFIMjdPT0lZNGVmcndySksyb0tBWHlvYzZV', 0, 0, 0, NULL, '2018-04-13 04:04:48', '2018-04-13 07:04:48')
ERROR - 2018-04-13 16:04:48 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:04:48 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:04:48 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 16:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 16:04:48 --> Total execution time: 1.0709
DEBUG - 2018-04-13 16:05:13 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:05:13 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:05:13 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:05:13 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:05:13 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (41, 'NDEqZ2hRVXI0MHh5aFdnRTh1Mm1sMGxMN2o5cmNMVnZNZEV5QjBMRlNYZnJrcnpYYWlJUTZROGFtWE93R1hiMGZJZ2RPeHVmemlQSGZrTEU0dGdISzROV3VZa1kyd2tT', 0, 0, 0, NULL, '2018-04-13 04:05:13', '2018-04-13 07:05:13')
ERROR - 2018-04-13 16:05:14 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:05:14 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:05:14 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
DEBUG - 2018-04-13 16:05:14 --> Total execution time: 1.3918
DEBUG - 2018-04-13 16:06:24 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:06:24 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:06:24 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:06:24 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:06:25 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (42, 'NDIqdEY1emlLV0pjemtzdEJsVzBQQlQ3SWF6RWRERVlPN25UdGNzTUVZN3NsMjRpWnR3N3pUZWh6bm5DVndIdDhxcEc5RmRDcm5tNlo2eXVmWVpCYnlxT2lYNFd2TUNs', 0, 0, 0, NULL, '2018-04-13 04:06:25', '2018-04-13 07:06:25')
ERROR - 2018-04-13 16:06:25 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:06:26 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:06:26 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 16:06:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 16:06:26 --> Total execution time: 1.3983
DEBUG - 2018-04-13 16:07:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:07:08 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:07:08 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:07:08 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:07:09 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 189
ERROR - 2018-04-13 16:07:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 189
ERROR - 2018-04-13 16:07:09 --> Severity: Warning --> Missing argument 1 for MDataUser::getAPIKeyById(), called in C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php on line 192 and defined C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 49
ERROR - 2018-04-13 16:07:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 50
ERROR - 2018-04-13 16:07:09 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:07:10 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
ERROR - 2018-04-13 16:07:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\pertamina_now\system\core\Exceptions.php:272) C:\xampp\htdocs\pertamina_now\system\core\Common.php 573
DEBUG - 2018-04-13 16:07:10 --> Total execution time: 1.2607
DEBUG - 2018-04-13 16:07:26 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:07:26 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:07:26 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:07:26 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:07:26 --> Severity: Warning --> Missing argument 1 for MDataUser::getAPIKeyById(), called in C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php on line 192 and defined C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 49
ERROR - 2018-04-13 16:07:26 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 50
ERROR - 2018-04-13 16:07:26 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:07:27 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
ERROR - 2018-04-13 16:07:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\pertamina_now\system\core\Exceptions.php:272) C:\xampp\htdocs\pertamina_now\system\core\Common.php 573
DEBUG - 2018-04-13 16:07:27 --> Total execution time: 1.7426
DEBUG - 2018-04-13 16:07:39 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:07:39 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:07:39 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:07:39 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:07:40 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:07:41 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:07:41 --> Total execution time: 1.4427
DEBUG - 2018-04-13 16:07:54 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:07:54 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:07:54 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:07:54 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:07:55 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (43, 'alJId1JRNjl1N3Z5VTNuUWx0R0J2SVRWQ0VZcHBCb2E1cDhMbnJFaXV3VW44Wm41eUgzMXMwbWczSmpxNWVsQktscm1McDNQbWhiemZqZ0hFamlPaEZJWW5id09E', 0, 0, 0, NULL, '2018-04-13 04:07:55', '2018-04-13 07:07:55')
ERROR - 2018-04-13 16:07:55 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:07:55 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:07:55 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 224
ERROR - 2018-04-13 16:07:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 16:07:56 --> Total execution time: 1.1858
DEBUG - 2018-04-13 16:08:17 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:08:18 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:08:18 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:08:18 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:08:18 --> Query error: Unknown column 'expired' in 'field list' - Invalid query: INSERT INTO `user_key` (`id_user`, `key_user`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`, `expired`) VALUES (44, 'Z1FkMERCODJCeVEwcHppd0taWEZRRE8yclNqSkp4cmtyWUZXTTFXOHUySzJNUTRlbE5sTnJLeWtMMmFXeHU5ZHV0WmZPUENDZ1N4cjF1SWlQWkJoVWVhMFl6VHhl', 0, 0, 0, NULL, '2018-04-13 04:08:18', '2018-04-13 07:08:18')
ERROR - 2018-04-13 16:08:19 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
ERROR - 2018-04-13 16:08:19 --> Severity: Notice --> Undefined variable: key_user C:\xampp\htdocs\pertamina_now\application\models\MDataUser.php 54
ERROR - 2018-04-13 16:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 225
DEBUG - 2018-04-13 16:08:19 --> Total execution time: 1.3476
DEBUG - 2018-04-13 16:10:04 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:10:05 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:10:05 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:10:05 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:10:06 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 218
DEBUG - 2018-04-13 16:10:07 --> Total execution time: 2.2340
DEBUG - 2018-04-13 16:10:28 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:10:29 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:10:29 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:10:29 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:10:29 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 241
ERROR - 2018-04-13 16:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 242
ERROR - 2018-04-13 16:10:29 --> Severity: Notice --> Undefined index: x-api-key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 327
ERROR - 2018-04-13 16:10:29 --> Severity: Notice --> Undefined variable: expired C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 334
DEBUG - 2018-04-13 16:10:29 --> Total execution time: 0.9631
DEBUG - 2018-04-13 16:11:48 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:11:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-13 16:11:48 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 339
DEBUG - 2018-04-13 16:11:54 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:11:54 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:11:54 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:11:54 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:11:55 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 241
ERROR - 2018-04-13 16:11:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 242
ERROR - 2018-04-13 16:11:55 --> Severity: Notice --> Undefined index: x-api-key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 327
ERROR - 2018-04-13 16:11:55 --> Severity: Notice --> Undefined variable: expired C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 335
ERROR - 2018-04-13 16:11:55 --> Severity: Notice --> Undefined variable: key1 C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 340
ERROR - 2018-04-13 16:11:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\pertamina_now\system\core\Exceptions.php:272) C:\xampp\htdocs\pertamina_now\system\core\Common.php 573
DEBUG - 2018-04-13 16:11:55 --> Total execution time: 1.4074
DEBUG - 2018-04-13 16:13:14 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:13:14 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:13:14 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:13:14 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:13:16 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:13:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:13:16 --> Total execution time: 1.3121
DEBUG - 2018-04-13 16:14:24 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:14:24 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:14:24 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:14:24 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:14:24 --> Severity: Notice --> Undefined index: x-api-key C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 327
ERROR - 2018-04-13 16:14:24 --> Severity: Notice --> Undefined variable: expired C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 335
ERROR - 2018-04-13 16:14:24 --> Severity: Notice --> Undefined variable: key1 C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 340
DEBUG - 2018-04-13 16:14:25 --> Total execution time: 0.2851
DEBUG - 2018-04-13 16:14:53 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:14:53 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:14:53 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:14:53 --> Nexmo class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 16:14:54 --> Total execution time: 0.3317
DEBUG - 2018-04-13 16:14:59 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:14:59 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:14:59 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:14:59 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:15:00 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 241
ERROR - 2018-04-13 16:15:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 242
DEBUG - 2018-04-13 16:15:00 --> Total execution time: 1.4412
DEBUG - 2018-04-13 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:15:14 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:15:14 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:15:14 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:15:15 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 241
ERROR - 2018-04-13 16:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 242
DEBUG - 2018-04-13 16:15:16 --> Total execution time: 1.2440
DEBUG - 2018-04-13 16:15:30 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:15:30 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:15:30 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:15:30 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:15:31 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:15:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:15:31 --> Total execution time: 1.2368
DEBUG - 2018-04-13 16:16:12 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:16:12 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:16:12 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:16:12 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:16:12 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
DEBUG - 2018-04-13 16:16:13 --> Total execution time: 1.0319
DEBUG - 2018-04-13 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:18:12 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:18:12 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:18:12 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:18:13 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:18:13 --> Total execution time: 1.1638
DEBUG - 2018-04-13 16:19:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:19:09 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:19:09 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:19:09 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:19:09 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
DEBUG - 2018-04-13 16:19:10 --> Total execution time: 1.1239
DEBUG - 2018-04-13 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:19:25 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:19:25 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:19:25 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:19:26 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:19:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:19:26 --> Total execution time: 1.0159
DEBUG - 2018-04-13 16:19:36 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:19:36 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:19:36 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:19:36 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:19:37 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:19:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:19:37 --> Total execution time: 1.0615
DEBUG - 2018-04-13 16:19:46 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:19:46 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:19:46 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:19:46 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:19:47 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:19:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:19:47 --> Total execution time: 1.3344
DEBUG - 2018-04-13 16:19:56 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:19:56 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:19:56 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:19:56 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:19:57 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
DEBUG - 2018-04-13 16:19:57 --> Total execution time: 1.1653
DEBUG - 2018-04-13 16:21:58 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:21:58 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:21:58 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:21:58 --> Nexmo class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 16:21:59 --> Total execution time: 1.2855
DEBUG - 2018-04-13 16:22:21 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:22:21 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:22:21 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:22:21 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:22:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:22:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:22:22 --> Total execution time: 0.9916
DEBUG - 2018-04-13 16:22:38 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:22:38 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:22:38 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:22:38 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:22:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:22:39 --> Total execution time: 1.3042
DEBUG - 2018-04-13 16:22:54 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:22:54 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:22:54 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:22:54 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:22:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:22:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:22:55 --> Total execution time: 1.1767
DEBUG - 2018-04-13 16:23:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:23:09 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:23:09 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:23:09 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:23:10 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 193
ERROR - 2018-04-13 16:23:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 199
DEBUG - 2018-04-13 16:23:10 --> Total execution time: 1.3276
DEBUG - 2018-04-13 16:23:21 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:23:21 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:23:21 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:23:21 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:23:22 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:23:22 --> Total execution time: 0.9326
DEBUG - 2018-04-13 16:23:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:23:32 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:23:32 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:23:32 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:23:33 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
DEBUG - 2018-04-13 16:23:33 --> Total execution time: 1.0823
DEBUG - 2018-04-13 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:24:58 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:24:58 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:24:58 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:24:59 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:24:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:24:59 --> Total execution time: 1.1310
DEBUG - 2018-04-13 16:25:07 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:25:07 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:25:07 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:25:07 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:25:08 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
DEBUG - 2018-04-13 16:25:08 --> Total execution time: 1.0362
DEBUG - 2018-04-13 16:25:18 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:25:18 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:25:18 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:25:18 --> Nexmo class already loaded. Second attempt ignored.
DEBUG - 2018-04-13 16:25:19 --> Total execution time: 1.1609
DEBUG - 2018-04-13 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:25:37 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:25:37 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:25:37 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:25:38 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
DEBUG - 2018-04-13 16:25:38 --> Total execution time: 1.0182
DEBUG - 2018-04-13 16:27:09 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:27:09 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:27:09 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:27:09 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:27:10 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
DEBUG - 2018-04-13 16:27:10 --> Total execution time: 1.1496
DEBUG - 2018-04-13 16:27:57 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:27:57 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:27:57 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:27:57 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:27:58 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
DEBUG - 2018-04-13 16:27:58 --> Total execution time: 1.2393
DEBUG - 2018-04-13 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:29:20 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:29:20 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:29:20 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:29:21 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:29:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:29:21 --> Total execution time: 1.0759
DEBUG - 2018-04-13 16:29:28 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 16:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 16:29:28 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/nexmo.php
DEBUG - 2018-04-13 16:29:28 --> Config file loaded: C:\xampp\htdocs\pertamina_now\application\config/rest.php
DEBUG - 2018-04-13 16:29:28 --> Nexmo class already loaded. Second attempt ignored.
ERROR - 2018-04-13 16:29:29 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 194
ERROR - 2018-04-13 16:29:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\pertamina_now\application\controllers\api\Collection.php 200
DEBUG - 2018-04-13 16:29:29 --> Total execution time: 1.2011
