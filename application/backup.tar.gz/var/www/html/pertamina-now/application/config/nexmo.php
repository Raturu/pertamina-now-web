<?php  (! defined('BASEPATH')) and exit('No direct script access allowed');
	$config['api_key'] = 'fad4f805';
	$config['api_secret'] = 'ZfnUGWVPs9h5Q0cp';