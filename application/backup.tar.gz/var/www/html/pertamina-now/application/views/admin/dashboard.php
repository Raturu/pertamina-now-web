<div class="content-wrapper" style="background-color: white;">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <img src="<?php echo base_url() ?>assets/dist/img/logo.png" class="img-responsive">
    </h1>
  </section>
</div>
